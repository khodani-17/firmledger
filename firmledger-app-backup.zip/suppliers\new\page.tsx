import Link from "next/link";
import { createSupplier } from "@/app/actions";
import { requireRole } from "@/lib/permissions";

export default async function NewSupplier() {
  await requireRole(["OWNER", "ADMIN", "FINANCE", "ACCOUNTANT"]);

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          Firm<span>Ledger</span>
        </div>

        <Link className="nav-link" href="/suppliers">
          ← Suppliers
        </Link>
      </aside>

      <main className="main">
        <section className="content">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "space-between",
              gap: "24px",
              marginBottom: "28px",
            }}
          >
            <div>
              <div className="metric-label" style={{ marginBottom: "8px" }}>
                SUPPLIERS
              </div>

              <h1 className="page-title" style={{ marginBottom: "8px" }}>
                New supplier
              </h1>

              <p
                style={{
                  margin: 0,
                  color: "#667085",
                  fontSize: "14px",
                  lineHeight: 1.6,
                }}
              >
                Add a supplier to your accounts payable records.
              </p>
            </div>

            <Link className="secondary-button" href="/suppliers">
              Cancel
            </Link>
          </div>

          <form action={createSupplier}>
            <div
              className="card"
              style={{
                padding: "28px",
                maxWidth: "900px",
              }}
            >
              <div style={{ marginBottom: "26px" }}>
                <h2
                  style={{
                    margin: 0,
                    fontSize: "17px",
                    fontWeight: 650,
                  }}
                >
                  Supplier details
                </h2>

                <p
                  style={{
                    margin: "6px 0 0",
                    color: "#667085",
                    fontSize: "13px",
                  }}
                >
                  Enter the supplier's basic business information.
                </p>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "minmax(0, 2fr) minmax(220px, 1fr)",
                  gap: "22px",
                }}
              >
                <div>
                  <label
                    htmlFor="name"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Supplier name
                  </label>

                  <input
                    id="name"
                    name="name"
                    required
                    placeholder="e.g. ABC Legal Supplies"
                    style={{
                      width: "100%",
                      minHeight: "46px",
                      padding: "0 14px",
                      border: "1px solid #d0d5dd",
                      borderRadius: "8px",
                      background: "#fff",
                      fontSize: "14px",
                      outline: "none",
                    }}
                  />
                </div>

                <div>
                  <label
                    htmlFor="type"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Supplier type
                  </label>

                  <select
                    id="type"
                    name="type"
                    defaultValue="COMPANY"
                    style={{
                      width: "100%",
                      minHeight: "46px",
                      padding: "0 14px",
                      border: "1px solid #d0d5dd",
                      borderRadius: "8px",
                      background: "#fff",
                      fontSize: "14px",
                      outline: "none",
                    }}
                  >
                    <option value="COMPANY">Company</option>
                    <option value="INDIVIDUAL">Individual</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>
              </div>

              <div
                style={{
                  height: "1px",
                  background: "#eaecf0",
                  margin: "30px 0",
                }}
              />

              <div style={{ marginBottom: "22px" }}>
                <h2
                  style={{
                    margin: 0,
                    fontSize: "17px",
                    fontWeight: 650,
                  }}
                >
                  Registration details
                </h2>

                <p
                  style={{
                    margin: "6px 0 0",
                    color: "#667085",
                    fontSize: "13px",
                  }}
                >
                  Optional tax information for the supplier.
                </p>
              </div>

              <div style={{ maxWidth: "420px" }}>
                <label
                  htmlFor="vatNumber"
                  style={{
                    display: "block",
                    fontSize: "13px",
                    fontWeight: 600,
                    marginBottom: "8px",
                  }}
                >
                  VAT number
                </label>

                <input
                  id="vatNumber"
                  name="vatNumber"
                  placeholder="Optional"
                  style={{
                    width: "100%",
                    minHeight: "46px",
                    padding: "0 14px",
                    border: "1px solid #d0d5dd",
                    borderRadius: "8px",
                    background: "#fff",
                    fontSize: "14px",
                    outline: "none",
                  }}
                />
              </div>

              <div
                style={{
                  height: "1px",
                  background: "#eaecf0",
                  margin: "30px 0",
                }}
              />

              <div style={{ marginBottom: "22px" }}>
                <h2
                  style={{
                    margin: 0,
                    fontSize: "17px",
                    fontWeight: 650,
                  }}
                >
                  Contact information
                </h2>

                <p
                  style={{
                    margin: "6px 0 0",
                    color: "#667085",
                    fontSize: "13px",
                  }}
                >
                  Add contact details for supplier communication.
                </p>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "minmax(0, 1fr) minmax(0, 1fr)",
                  gap: "22px",
                }}
              >
                <div>
                  <label
                    htmlFor="email"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Email
                  </label>

                  <input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="supplier@example.com"
                    style={{
                      width: "100%",
                      minHeight: "46px",
                      padding: "0 14px",
                      border: "1px solid #d0d5dd",
                      borderRadius: "8px",
                      background: "#fff",
                      fontSize: "14px",
                      outline: "none",
                    }}
                  />
                </div>

                <div>
                  <label
                    htmlFor="phone"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Phone
                  </label>

                  <input
                    id="phone"
                    name="phone"
                    type="tel"
                    placeholder="e.g. 012 345 6789"
                    style={{
                      width: "100%",
                      minHeight: "46px",
                      padding: "0 14px",
                      border: "1px solid #d0d5dd",
                      borderRadius: "8px",
                      background: "#fff",
                      fontSize: "14px",
                      outline: "none",
                    }}
                  />
                </div>
              </div>

              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "12px",
                  marginTop: "34px",
                  paddingTop: "22px",
                  borderTop: "1px solid #eaecf0",
                }}
              >
                <Link className="secondary-button" href="/suppliers">
                  Cancel
                </Link>

                <button className="primary-button" type="submit">
                  Save supplier
                </button>
              </div>
            </div>
          </form>
        </section>
      </main>
    </div>
  );
}