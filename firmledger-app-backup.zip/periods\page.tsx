import Link from "next/link";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";
import {
  createFinancialPeriod,
  closeFinancialPeriod,
} from "@/app/actions";

export default async function Periods() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const rows = await prisma.financialPeriod.findMany({
    where: {
      firmId: u.firmId,
    },
    orderBy: {
      startDate: "desc",
    },
  });

  const openPeriod = rows.find(
    (period) => period.status === "OPEN"
  );

  const closedPeriods = rows.filter(
    (period) => period.status !== "OPEN"
  );

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="flex items-center justify-between gap-4">
            <h1 className="text-sm font-semibold tracking-tight text-slate-950">
              Financial periods
            </h1>

            <a
              href="#create-period"
              className="inline-flex h-9 items-center justify-center bg-slate-950 px-4 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              New period
            </a>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] space-y-4 px-6 py-2">
        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2">
            <div>
              <span className="text-xs font-medium text-slate-600">
                Current period
              </span>

              <span
                className={`ml-3 badge ${
                  openPeriod ? "" : "status-danger"
                }`}
              >
                {openPeriod ? "OPEN" : "NO OPEN PERIOD"}
              </span>
            </div>

            {openPeriod && (
              <form action={closeFinancialPeriod}>
                <input
                  type="hidden"
                  name="periodId"
                  value={openPeriod.id}
                />

                <button
                  type="submit"
                  className="text-xs font-semibold text-slate-600 hover:text-slate-950"
                >
                  Close period →
                </button>
              </form>
            )}
          </div>

          <div className="px-4 py-2">
            {openPeriod ? (
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="text-base font-semibold text-slate-950">
                    {openPeriod.name}
                  </div>

                  <div className="mt-0.5 text-xs text-slate-500">
                    {openPeriod.startDate.toLocaleDateString("en-ZA")} –{" "}
                    {openPeriod.endDate.toLocaleDateString("en-ZA")}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
                    Posting
                  </div>

                  <div className="text-sm font-semibold text-slate-900">
                    Allowed
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <div className="text-sm font-semibold text-slate-950">
                  No open financial period
                </div>

                <div className="mt-0.5 text-xs text-slate-500">
                  Posting is blocked until a financial period is created.
                </div>
              </div>
            )}
          </div>
        </section>

        <section
          id="create-period"
          className="border border-slate-200 bg-white"
        >
          <div className="border-b border-slate-200 px-4 py-2">
            <span className="text-xs font-medium text-slate-600">
              Create financial period
            </span>
          </div>

          <form
            action={createFinancialPeriod}
            className="grid grid-cols-1 gap-3 p-4 md:grid-cols-[1.4fr_1fr_1fr_auto]"
          >
            <label className="block">
              <span className="mb-1 block text-[11px] font-medium text-slate-600">
                Period name
              </span>

              <input
                name="name"
                placeholder="2026 Financial Year"
                required
                className="h-9 w-full border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-slate-700 focus:ring-1 focus:ring-slate-700"
              />
            </label>

            <label className="block">
              <span className="mb-1 block text-[11px] font-medium text-slate-600">
                Start date
              </span>

              <input
                name="startDate"
                type="date"
                required
                className="h-9 w-full border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-slate-700 focus:ring-1 focus:ring-slate-700"
              />
            </label>

            <label className="block">
              <span className="mb-1 block text-[11px] font-medium text-slate-600">
                End date
              </span>

              <input
                name="endDate"
                type="date"
                required
                className="h-9 w-full border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-slate-700 focus:ring-1 focus:ring-slate-700"
              />
            </label>

            <button
              type="submit"
              className="h-9 self-end bg-slate-950 px-4 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              Create period
            </button>
          </form>
        </section>

        <section className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Posting control
            </div>

            <div className="mt-1 text-base font-semibold text-slate-950">
              {openPeriod ? "Posting allowed" : "Posting blocked"}
            </div>

            <div className="mt-0.5 text-xs text-slate-500">
              New invoices and accounting entries require an open period.
            </div>
          </div>

          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Period summary
            </div>

            <div className="mt-2 flex items-center gap-8">
              <div>
                <div className="text-[10px] text-slate-500">Open</div>
                <div className="text-base font-semibold text-slate-950">
                  {openPeriod ? 1 : 0}
                </div>
              </div>

              <div>
                <div className="text-[10px] text-slate-500">Closed</div>
                <div className="text-base font-semibold text-slate-950">
                  {closedPeriods.length}
                </div>
              </div>

              <div>
                <div className="text-[10px] text-slate-500">Total</div>
                <div className="text-base font-semibold text-slate-950">
                  {rows.length}
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2">
            <span className="text-xs font-medium text-slate-600">
              Period history
            </span>

            <span className="text-xs text-slate-500">
              {rows.length} {rows.length === 1 ? "period" : "periods"}
            </span>
          </div>

          {rows.length === 0 ? (
            <div className="px-4 py-6 text-center">
              <p className="text-sm font-medium text-slate-900">
                No financial periods
              </p>

              <p className="mt-1 text-xs text-slate-500">
                Create a period above.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Period</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {rows.map((period) => (
                    <tr key={period.id}>
                      <td>
                        <strong>{period.name}</strong>
                      </td>

                      <td>
                        {period.startDate.toLocaleDateString("en-ZA")}
                      </td>

                      <td>
                        {period.endDate.toLocaleDateString("en-ZA")}
                      </td>

                      <td>
                        <span className="badge">
                          {period.status}
                        </span>
                      </td>

                      <td>
                        {period.status === "OPEN" ? (
                          <form action={closeFinancialPeriod}>
                            <input
                              type="hidden"
                              name="periodId"
                              value={period.id}
                            />

                            <button
                              type="submit"
                              className="text-xs font-semibold text-slate-600 hover:text-slate-950"
                            >
                              Close →
                            </button>
                          </form>
                        ) : (
                          <span className="text-xs text-slate-500">
                            {period.closedAt
                              ? `Closed ${period.closedAt.toLocaleDateString(
                                  "en-ZA"
                                )}`
                              : "Closed"}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}