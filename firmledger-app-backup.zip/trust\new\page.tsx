import Link from "next/link";
import {
  createTrustAccount,
  createTrustTransaction,
} from "@/app/actions";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function NewTrust({
  searchParams,
}: {
  searchParams: Promise<{ transaction?: string }>;
}) {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const [accounts, clients, matters] = await Promise.all([
    prisma.trustAccount.findMany({
      where: {
        firmId: u.firmId,
        active: true,
      },
      orderBy: { name: "asc" },
    }),
    prisma.client.findMany({
      where: {
        firmId: u.firmId,
        active: true,
      },
      orderBy: { displayName: "asc" },
    }),
    prisma.matter.findMany({
      where: {
        firmId: u.firmId,
        status: { not: "ARCHIVED" },
      },
      include: { client: true },
      orderBy: { matterNumber: "desc" },
    }),
  ]);

  await searchParams;

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Link
                href="/trust"
                className="text-sm text-slate-500 transition hover:text-slate-900"
              >
                ← Trust
              </Link>
              <span className="text-slate-300">/</span>
              <h1 className="text-sm font-semibold tracking-tight text-slate-950">
                New trust entry
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] px-6 py-2">
        <div className="grid gap-4 lg:grid-cols-2">
          <section className="border border-slate-200 bg-white">
            <div className="border-b border-slate-200 px-4 py-2">
              <h2 className="text-sm font-semibold text-slate-900">
                New trust bank account
              </h2>
            </div>

            <form action={createTrustAccount} className="form-grid p-4">
              <label>
                Name
                <input name="name" required />
              </label>

              <label>
                Bank
                <input name="bankName" />
              </label>

              <label>
                Account number
                <input name="accountNumber" />
              </label>

              <div className="pt-1">
                <button className="primary-button" type="submit">
                  Create trust account
                </button>
              </div>
            </form>
          </section>

          <section className="border border-slate-200 bg-white">
            <div className="border-b border-slate-200 px-4 py-2">
              <h2 className="text-sm font-semibold text-slate-900">
                Record client-money transaction
              </h2>
            </div>

            <form action={createTrustTransaction} className="form-grid p-4">
              <label>
                Trust account
                <select name="trustAccountId" required>
                  {accounts.map((account) => (
                    <option key={account.id} value={account.id}>
                      {account.name}
                    </option>
                  ))}
                </select>
              </label>

              <label>
                Client
                <select name="clientId" required>
                  <option value="">Select client</option>
                  {clients.map((client) => (
                    <option key={client.id} value={client.id}>
                      {client.displayName}
                    </option>
                  ))}
                </select>
              </label>

              <label>
                Matter
                <select name="matterId">
                  <option value="">No matter</option>
                  {matters.map((matter) => (
                    <option key={matter.id} value={matter.id}>
                      {matter.matterNumber} · {matter.client.displayName}
                    </option>
                  ))}
                </select>
              </label>

              <label>
                Type
                <select name="type">
                  <option value="RECEIPT">Receipt</option>
                  <option value="PAYMENT">Payment</option>
                  <option value="TRANSFER">Transfer</option>
                  <option value="INTEREST">Interest</option>
                  <option value="FEE">Fee</option>
                  <option value="REVERSAL">Reversal</option>
                </select>
              </label>

              <label>
                Amount
                <input
                  name="amount"
                  type="number"
                  min="0.01"
                  step="0.01"
                  required
                />
              </label>

              <label>
                Reference
                <input name="reference" />
              </label>

              <label>
                Description
                <input name="description" required />
              </label>

              <div className="pt-1">
                <button className="primary-button" type="submit">
                  Post transaction
                </button>
              </div>
            </form>
          </section>
        </div>
      </div>
    </main>
  );
}