
import Link from "next/link";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

function formatMoney(value: number) {
  return `R ${value.toLocaleString("en-ZA", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    OPEN: "border-slate-200 bg-slate-50 text-slate-700",
    IN_PROGRESS: "border-amber-200 bg-amber-50 text-amber-800",
    COMPLETED: "border-emerald-200 bg-emerald-50 text-emerald-800",
    "NOT STARTED": "border-slate-200 bg-slate-50 text-slate-500",
  };

  return (
    <span
      className={`inline-flex items-center whitespace-nowrap rounded-md border px-2 py-0.5 text-xs font-medium ${
        styles[status] ??
        "border-slate-200 bg-slate-50 text-slate-700"
      }`}
    >
      {status.replaceAll("_", " ")}
    </span>
  );
}

function SummaryCard({
  label,
  value,
  description,
}: {
  label: string;
  value: number;
  description: string;
}) {
  return (
    <div className="flex min-h-[100px] min-w-0 flex-col justify-between rounded-md border border-slate-200 bg-white p-3 shadow-sm">
      <p className="truncate text-xs font-medium text-slate-500">
        {label}
      </p>

      <p className="mt-2 text-xl font-semibold leading-6 tabular-nums text-slate-950">
        {value}
      </p>

      <p className="mt-1 text-xs leading-4 text-slate-500">
        {description}
      </p>
    </div>
  );
}

function EmptyState({
  title,
  description,
  action,
}: {
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center px-4 py-7 text-center">
      <div className="flex h-8 w-8 items-center justify-center rounded-md border border-slate-200 bg-slate-50">
        <svg
          aria-hidden="true"
          viewBox="0 0 24 24"
          fill="none"
          className="h-4 w-4 text-slate-500"
        >
          <path
            d="M4 7.5h16M6.5 4h11A2.5 2.5 0 0 1 20 6.5v11a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5v-11A2.5 2.5 0 0 1 6.5 4Z"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="m8 12 2.5 2.5L16 9"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>

      <h3 className="mt-3 text-sm font-semibold text-slate-900">
        {title}
      </h3>

      <p className="mt-1 max-w-md text-sm leading-5 text-slate-500">
        {description}
      </p>

      {action ? <div className="mt-3">{action}</div> : null}
    </div>
  );
}

export default async function TrustReconciliation() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const [accounts, reconciliations] = await Promise.all([
    prisma.trustAccount.findMany({
      where: {
        firmId: u.firmId,
        active: true,
      },
      orderBy: {
        name: "asc",
      },
    }),

    prisma.trustReconciliation.findMany({
      where: {
        firmId: u.firmId,
      },
      include: {
        trustAccount: {
          select: {
            name: true,
          },
        },
      },
      orderBy: {
        reconciliationDate: "desc",
      },
      take: 20,
    }),
  ]);

  const latestByAccount = accounts.map((account) => ({
    account,
    latest: reconciliations.find(
      (reconciliation) =>
        reconciliation.trustAccountId === account.id
    ),
  }));

  const openCount = reconciliations.filter(
    (reconciliation) => reconciliation.status === "OPEN"
  ).length;

  const inProgressCount = reconciliations.filter(
    (reconciliation) => reconciliation.status === "IN_PROGRESS"
  ).length;

  const completedCount = reconciliations.filter(
    (reconciliation) => reconciliation.status === "COMPLETED"
  ).length;

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      {/* Breadcrumb navigation */}
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-3 px-5 py-3">
          <nav
            aria-label="Breadcrumb"
            className="flex items-center gap-2 text-sm"
          >
            <Link
              href="/trust"
              className="text-slate-500 transition hover:text-slate-900"
            >
              Trust
            </Link>

            <span className="text-slate-300">/</span>

            <span className="font-medium text-slate-900">
              Reconciliation
            </span>
          </nav>

          <Link
            href="/trust"
            className="text-xs font-medium text-slate-600 transition hover:text-slate-950"
          >
            ← Trust overview
          </Link>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] space-y-4 px-5 py-5">
        {/* Page heading */}
        <header className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
          <div className="min-w-0">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Trust accounting
            </p>

            <h1 className="mt-1 text-2xl font-semibold leading-tight tracking-tight text-slate-950">
              Trust reconciliation
            </h1>

            <p className="mt-1.5 max-w-2xl text-sm leading-5 text-slate-600">
              Reconcile trust bank statement balances against your
              trust ledger and review outstanding differences.
            </p>
          </div>

          <Link
            href="/trust/reconciliation/new"
            className="inline-flex min-h-9 shrink-0 items-center justify-center gap-2 self-start rounded-md bg-slate-950 px-3.5 py-2 text-sm font-medium text-white transition hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2 sm:self-center"
          >
            <span aria-hidden="true" className="text-base leading-none">
              +
            </span>
            New reconciliation
          </Link>
        </header>

        {/* Summary cards */}
        <section aria-label="Reconciliation summary">
          <div className="mb-2 flex items-center justify-between gap-3">
            <h2 className="text-sm font-semibold text-slate-900">
              Overview
            </h2>

            <span className="text-xs text-slate-500">
              Latest 20 records
            </span>
          </div>

          <div className="grid grid-cols-1 items-stretch gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <SummaryCard
              label="Open"
              value={openCount}
              description="Awaiting reconciliation"
            />

            <SummaryCard
              label="In progress"
              value={inProgressCount}
              description="Currently being reconciled"
            />

            <SummaryCard
              label="Completed"
              value={completedCount}
              description="Marked as completed"
            />

            <SummaryCard
              label="Active trust accounts"
              value={accounts.length}
              description="Available for reconciliation"
            />
          </div>
        </section>

        {/* Active trust accounts */}
        <section className="overflow-hidden rounded-md border border-slate-200 bg-white shadow-sm">
          <div className="flex flex-col justify-between gap-2 border-b border-slate-200 px-4 py-3 sm:flex-row sm:items-center">
            <div>
              <h2 className="text-sm font-semibold text-slate-950">
                Trust accounts
              </h2>

              <p className="mt-0.5 text-xs text-slate-500">
                Latest reconciliation for each active account.
              </p>
            </div>

            <span className="text-xs text-slate-500">
              {accounts.length}{" "}
              {accounts.length === 1 ? "account" : "accounts"}
            </span>
          </div>

          {latestByAccount.length === 0 ? (
            <EmptyState
              title="No active trust accounts"
              description="Active trust accounts will appear here when they are available for reconciliation."
              action={
                <Link
                  href="/trust"
                  className="inline-flex min-h-8 items-center justify-center rounded-md border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-700 transition hover:bg-slate-50"
                >
                  View trust overview
                </Link>
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[850px] border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-slate-500">
                      Trust account
                    </th>

                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-slate-500">
                      Last reconciliation
                    </th>

                    <th className="px-3 py-2.5 text-right text-xs font-semibold text-slate-500">
                      Statement balance
                    </th>

                    <th className="px-3 py-2.5 text-right text-xs font-semibold text-slate-500">
                      Ledger balance
                    </th>

                    <th className="px-3 py-2.5 text-right text-xs font-semibold text-slate-500">
                      Difference
                    </th>

                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-slate-500">
                      Status
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {latestByAccount.map(({ account, latest }) => (
                    <tr
                      key={account.id}
                      className="transition-colors hover:bg-slate-50"
                    >
                      <td className="px-3 py-3 font-medium text-slate-900">
                        {account.name}
                      </td>

                      <td className="whitespace-nowrap px-3 py-3 text-slate-600">
                        {latest
                          ? new Date(
                              latest.reconciliationDate
                            ).toLocaleDateString("en-ZA")
                          : "Not reconciled"}
                      </td>

                      <td className="whitespace-nowrap px-3 py-3 text-right tabular-nums text-slate-700">
                        {latest
                          ? formatMoney(Number(latest.statementBalance))
                          : "—"}
                      </td>

                      <td className="whitespace-nowrap px-3 py-3 text-right tabular-nums text-slate-700">
                        {latest
                          ? formatMoney(Number(latest.ledgerBalance))
                          : "—"}
                      </td>

                      <td className="whitespace-nowrap px-3 py-3 text-right font-medium tabular-nums text-slate-900">
                        {latest
                          ? formatMoney(Number(latest.difference))
                          : "—"}
                      </td>

                      <td className="whitespace-nowrap px-3 py-3">
                        <StatusBadge
                          status={latest ? latest.status : "NOT STARTED"}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {/* Reconciliation history */}
        <section className="overflow-hidden rounded-md border border-slate-200 bg-white shadow-sm">
          <div className="flex flex-col justify-between gap-2 border-b border-slate-200 px-4 py-3 sm:flex-row sm:items-center">
            <div>
              <h2 className="text-sm font-semibold text-slate-950">
                Reconciliation history
              </h2>

              <p className="mt-0.5 text-xs text-slate-500">
                Recent trust reconciliation records and balances.
              </p>
            </div>

            <span className="text-xs text-slate-500">
              {reconciliations.length}{" "}
              {reconciliations.length === 1 ? "record" : "records"}
            </span>
          </div>

          {reconciliations.length === 0 ? (
            <EmptyState
              title="No reconciliation history yet"
              description="Saved trust reconciliations will appear here with their dates, balances, statuses, and notes."
              action={
                <Link
                  href="/trust/reconciliation/new"
                  className="inline-flex min-h-8 items-center justify-center rounded-md bg-slate-950 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-slate-800"
                >
                  Start a reconciliation
                </Link>
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1000px] border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-slate-500">
                      Date
                    </th>

                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-slate-500">
                      Trust account
                    </th>

                    <th className="px-3 py-2.5 text-right text-xs font-semibold text-slate-500">
                      Statement balance
                    </th>

                    <th className="px-3 py-2.5 text-right text-xs font-semibold text-slate-500">
                      Ledger balance
                    </th>

                    <th className="px-3 py-2.5 text-right text-xs font-semibold text-slate-500">
                      Difference
                    </th>

                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-slate-500">
                      Status
                    </th>

                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-slate-500">
                      Notes
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {reconciliations.map((reconciliation) => (
                    <tr
                      key={reconciliation.id}
                      className="transition-colors hover:bg-slate-50"
                    >
                      <td className="whitespace-nowrap px-3 py-3 text-slate-600">
                        {new Date(
                          reconciliation.reconciliationDate
                        ).toLocaleDateString("en-ZA")}
                      </td>

                      <td className="whitespace-nowrap px-3 py-3 font-medium text-slate-900">
                        {reconciliation.trustAccount.name}
                      </td>

                      <td className="whitespace-nowrap px-3 py-3 text-right tabular-nums text-slate-700">
                        {formatMoney(
                          Number(reconciliation.statementBalance)
                        )}
                      </td>

                      <td className="whitespace-nowrap px-3 py-3 text-right tabular-nums text-slate-700">
                        {formatMoney(
                          Number(reconciliation.ledgerBalance)
                        )}
                      </td>

                      <td className="whitespace-nowrap px-3 py-3 text-right font-medium tabular-nums text-slate-900">
                        {formatMoney(Number(reconciliation.difference))}
                      </td>

                      <td className="whitespace-nowrap px-3 py-3">
                        <StatusBadge status={reconciliation.status} />
                      </td>

                      <td className="max-w-[260px] px-3 py-3 text-slate-600">
                        <span
                          className="block truncate"
                          title={reconciliation.notes || undefined}
                        >
                          {reconciliation.notes || "—"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <p className="text-xs leading-5 text-slate-500">
          Review and investigate balance differences before finalising a
          reconciliation. Confirm the underlying records and supporting
          bank statement before relying on the displayed balances.
        </p>
      </div>
    </main>
  );
}