import Link from "next/link";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";
import { createExpense } from "@/app/actions";

export default async function NewExpense() {
  const user = await requireRole(["OWNER", "ADMIN", "FINANCE", "ACCOUNTANT"]);
  const [clients, matters, banks] = await Promise.all([
    prisma.client.findMany({ where: { firmId: user.firmId, active: true }, orderBy: { displayName: "asc" } }),
    prisma.matter.findMany({ where: { firmId: user.firmId, status: { not: "ARCHIVED" } }, include: { client: true }, orderBy: { matterNumber: "asc" } }),
    prisma.bankAccount.findMany({ where: { firmId: user.firmId, active: true }, orderBy: { name: "asc" } })
  ]);
  return <div className="shell"><aside className="sidebar"><div className="brand">Firm<span>Ledger</span></div><Link className="nav-link" href="/expenses">← Expenses</Link></aside><main className="main"><header className="topbar"><strong>Record expense</strong></header><section className="content"><h1 className="page-title">Record expense</h1><p className="page-subtitle">Capture a paid expense and post the bank, expense and input-VAT entries together.</p><div className="card form-card" style={{marginTop:24}}><form action={createExpense}>
    <label>Description<input name="description" required placeholder="Court filing fee" /></label>
    <label>Client (optional)<select name="clientId"><option value="">Firm expense</option>{clients.map(c=><option key={c.id} value={c.id}>{c.displayName} — {c.clientCode}</option>)}</select></label>
    <label>Matter (optional)<select name="matterId"><option value="">No matter</option>{matters.map(m=><option key={m.id} value={m.id}>{m.matterNumber} — {m.client.displayName} — {m.title}</option>)}</select></label>
    <label>Net amount<input name="amount" type="number" min="0.01" step="0.01" required placeholder="0.00" /></label>
    <label>Input VAT<input name="taxAmount" type="number" min="0" step="0.01" defaultValue="0" /></label>
    <label>Paid from<select name="bankAccountId" required><option value="">Select bank account</option>{banks.map(b=><option key={b.id} value={b.id}>{b.name}{b.bankName ? ` — ${b.bankName}` : ""}</option>)}</select></label>
    <label>Reference<input name="reference" placeholder="Supplier / EFT reference" /></label>
    <button className="primary-button" type="submit">Post expense</button>
  </form></div></section></main></div>;
}
