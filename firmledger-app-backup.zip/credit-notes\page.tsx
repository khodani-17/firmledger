import Link from "next/link";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function CreditNotes() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const rows = await prisma.creditNote.findMany({
    where: {
      firmId: u.firmId,
    },
    include: {
      client: true,
    },
    orderBy: {
      issueDate: "desc",
    },
  });

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          Firm<span>Ledger</span>
        </div>

        <Link className="nav-link" href="/">
          ← Dashboard
        </Link>

        <Link className="nav-link active" href="/credit-notes">
          Credit notes
        </Link>

        <Link className="nav-link" href="/billing">
          Billing
        </Link>
      </aside>

      <main className="main">
        <section className="content">
          <div className="page-heading">
            <div>
              <h1 className="page-title">Credit notes</h1>
              <p className="page-subtitle">
                Credit and adjust client invoices with an auditable record.
              </p>
            </div>

            <Link className="primary-button" href="/credit-notes/new">
              New credit note
            </Link>
          </div>

          <div className="card" style={{ marginTop: 24 }}>
            <table className="table">
              <thead>
                <tr>
                  <th>Credit note</th>
                  <th>Client</th>
                  <th>Date</th>
                  <th>Reason</th>
                  <th>Total</th>
                </tr>
              </thead>

              <tbody>
                {rows.map((row) => (
                  <tr key={row.id}>
                    <td>{row.creditNumber}</td>

                    <td>{row.client?.displayName ?? "—"}</td>

                    <td>
                      {row.issueDate.toLocaleDateString("en-ZA")}
                    </td>

                    <td>{row.reason}</td>

                    <td>R{Number(row.total).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}