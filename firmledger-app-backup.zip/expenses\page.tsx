import Link from "next/link";
import { requireUser } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function Expenses() {
  const u = await requireUser();

  const rows = await prisma.expense.findMany({
    where: {
      firmId: u.firmId,
    },
    include: {
      matter: true,
      client: true,
    },
    orderBy: {
      expenseDate: "desc",
    },
  });

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="flex items-center justify-between gap-4">
            <h1 className="text-sm font-semibold tracking-tight text-slate-950">
              Expenses
            </h1>

            <Link
              href="/expenses/new"
              className="inline-flex h-9 items-center justify-center bg-slate-950 px-4 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              Record expense
            </Link>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] px-6 py-2">
        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2">
            <span className="text-xs text-slate-500">
              {rows.length} {rows.length === 1 ? "expense" : "expenses"}
            </span>
          </div>

          {rows.length === 0 ? (
            <div className="px-4 py-6 text-center">
              <p className="text-sm font-medium text-slate-900">
                No expenses recorded
              </p>

              <p className="mt-1 text-xs text-slate-500">
                Record an expense to see it here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Matter</th>
                    <th>Status</th>
                    <th>Amount</th>
                  </tr>
                </thead>

                <tbody>
                  {rows.map((expense) => (
                    <tr key={expense.id}>
                      <td>
                        {expense.expenseDate.toLocaleDateString("en-ZA")}
                      </td>

                      <td>{expense.description}</td>

                      <td>
                        {expense.matter?.matterNumber ?? "—"}
                      </td>

                      <td>
                        <span className="badge">
                          {expense.status}
                        </span>
                      </td>

                      <td className="amount">
                        R{Number(expense.amount).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}