import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/permissions";
import LogoutButton from "@/app/logout-button";

export default async function Home() {
  const user = await requireUser();

  const [invoiceAgg, paidAgg, expenseAgg, outstanding] = await Promise.all([
    prisma.invoice.aggregate({
      where: {
        firmId: user.firmId,
        status: { not: "VOID" },
      },
      _sum: {
        total: true,
      },
    }),

    prisma.payment.aggregate({
      where: {
        firmId: user.firmId,
        status: "COMPLETED",
      },
      _sum: {
        amount: true,
      },
    }),

    prisma.expense.aggregate({
      where: {
        firmId: user.firmId,
      },
      _sum: {
        amount: true,
      },
    }),

    prisma.invoice.aggregate({
      where: {
        firmId: user.firmId,
        status: {
          in: ["SENT", "PARTIALLY_PAID", "OVERDUE"],
        },
      },
      _sum: {
        balanceDue: true,
      },
    }),
  ]);

  const money = (n: unknown) => `R${Number(n ?? 0).toFixed(2)}`;

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          Firm<span>Ledger</span>
        </div>

        {/* OVERVIEW */}
        <Link className="nav-link active" href="/">
          Overview
        </Link>

        {/* WORK */}
        <details className="nav-dropdown">
          <summary className="nav-section-toggle">
            <span>WORK</span>
            <span className="nav-chevron">▾</span>
          </summary>

          <div className="nav-dropdown-items">
            <Link className="nav-link" href="/clients">
              Clients
            </Link>

            <Link className="nav-link" href="/matters">
              Matters
            </Link>

            <Link className="nav-link" href="/documents">
              Documents
            </Link>
          </div>
        </details>

        {/* BILLING */}
        <details className="nav-dropdown">
          <summary className="nav-section-toggle">
            <span>BILLING</span>
            <span className="nav-chevron">▾</span>
          </summary>

          <div className="nav-dropdown-items">
            <Link className="nav-link" href="/billing">
              Invoices
            </Link>

            <Link className="nav-link" href="/payments">
              Payments
            </Link>

            <Link className="nav-link" href="/credit-notes">
              Credit Notes
            </Link>

            <Link className="nav-link" href="/recurring">
              Recurring
            </Link>
          </div>
        </details>

        {/* ACCOUNTING */}
        <div className="nav-section-fixed">
          <div className="nav-section-label">ACCOUNTING</div>

          <Link className="nav-link" href="/accounting">
            Overview
          </Link>

          <details className="nav-dropdown nav-dropdown-nested">
            <summary className="nav-section-toggle">
              <span>Reports &amp; Accounting</span>
              <span className="nav-chevron">▾</span>
            </summary>

            <div className="nav-dropdown-items">
              <Link className="nav-link" href="/accounting/general-ledger">
                General Ledger
              </Link>

              <Link className="nav-link" href="/accounting/trial-balance">
                Trial Balance
              </Link>

              <Link className="nav-link" href="/accounting/profit-loss">
                Profit &amp; Loss
              </Link>

              <Link className="nav-link" href="/accounting/balance-sheet">
                Balance Sheet
              </Link>

              <Link className="nav-link" href="/accounting/cash-flow">
                Cash Flow
              </Link>

              <Link
                className="nav-link"
                href="/accounting/accounts-receivable"
              >
                Accounts Receivable
              </Link>

              <Link
                className="nav-link"
                href="/accounting/accounts-payable"
              >
                Accounts Payable
              </Link>

              <Link
                className="nav-link"
                href="/accounting/bank-reconciliation"
              >
                Bank Reconciliation
              </Link>

              <Link className="nav-link" href="/accounting/cash-bank">
                Cash &amp; Bank
              </Link>

              <Link className="nav-link" href="/accounting/vat-tax">
                VAT / Tax
              </Link>

              <Link
                className="nav-link"
                href="/accounting/financial-periods"
              >
                Financial Periods
              </Link>
            </div>
          </details>
        </div>

        {/* BANKING */}
        <details className="nav-dropdown">
          <summary className="nav-section-toggle">
            <span>BANKING</span>
            <span className="nav-chevron">▾</span>
          </summary>

          <div className="nav-dropdown-items">
            <Link className="nav-link" href="/banking">
              Banking
            </Link>

            <Link className="nav-link" href="/banking/reconciliation">
              Reconciliation
            </Link>
          </div>
        </details>

        {/* PURCHASING */}
        <details className="nav-dropdown">
          <summary className="nav-section-toggle">
            <span>PURCHASING</span>
            <span className="nav-chevron">▾</span>
          </summary>

          <div className="nav-dropdown-items">
            <Link className="nav-link" href="/purchases">
              Purchases
            </Link>

            <Link className="nav-link" href="/suppliers">
              Suppliers
            </Link>

            <Link className="nav-link" href="/expenses">
              Expenses
            </Link>
          </div>
        </details>

        {/* TRUST */}
        <details className="nav-dropdown">
          <summary className="nav-section-toggle">
            <span>TRUST</span>
            <span className="nav-chevron">▾</span>
          </summary>

          <div className="nav-dropdown-items">
            <Link className="nav-link" href="/trust">
              Trust
            </Link>

            <Link className="nav-link" href="/trust/reconciliation">
              Reconciliation
            </Link>
          </div>
        </details>

        {/* REPORTS */}
        <details className="nav-dropdown">
          <summary className="nav-section-toggle">
            <span>REPORTS</span>
            <span className="nav-chevron">▾</span>
          </summary>

          <div className="nav-dropdown-items">
            <Link className="nav-link" href="/reports">
              Reports
            </Link>
          </div>
        </details>

        {/* SYSTEM */}
        <details className="nav-dropdown">
          <summary className="nav-section-toggle">
            <span>SYSTEM</span>
            <span className="nav-chevron">▾</span>
          </summary>

          <div className="nav-dropdown-items">
            <Link className="nav-link" href="/settings">
              Settings
            </Link>

            <Link className="nav-link" href="/audit">
              Audit
            </Link>
          </div>
        </details>
      </aside>

      <main className="main">
        <header className="topbar">
          <strong>{user.firm.name}</strong>

          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 14,
            }}
          >
            <span className="metric-label">
              {user.name} · {user.role}
            </span>

            <LogoutButton />
          </div>
        </header>

        <section className="content">
          <h1 className="page-title">Good morning</h1>

          <p className="page-subtitle">
            A simple financial view of your firm.
          </p>

          <div className="grid grid-4" style={{ marginTop: 26 }}>
            <Metric
              label="Revenue / billed"
              value={money(invoiceAgg._sum.total)}
            />

            <Metric
              label="Outstanding invoices"
              value={money(outstanding._sum.balanceDue)}
            />

            <Metric
              label="Payments received"
              value={money(paidAgg._sum.amount)}
            />

            <Metric
              label="Expenses"
              value={money(expenseAgg._sum.amount)}
            />
          </div>

          <div className="card" style={{ marginTop: 22 }}>
            <div className="section-title">Quick actions</div>

            <div className="action-grid">
              <Action
                href="/billing/new"
                title="New invoice"
                text="Create an invoice for a client or matter."
              />

              <Action
                href="/expenses/new"
                title="Record expense"
                text="Capture a firm expense or disbursement."
              />

              <Action
                href="/payments/new"
                title="Record payment"
                text="Record money received from a client."
              />

              <Action
                href="/banking/reconciliation"
                title="Reconcile bank"
                text="Match bank activity to transactions."
              />
            </div>
          </div>

          <div className="grid grid-2" style={{ marginTop: 22 }}>
            <div className="card">
              <div className="section-title">FirmLedger workflow</div>

              <p className="page-subtitle">
                Clients → Matters → Billing → Payments → Bank reconciliation
                → Accountant review → Month-end close → Reports.
              </p>
            </div>

            <div className="card">
              <div className="section-title">Current user</div>

              <p className="page-subtitle">
                You are signed in as <strong>{user.role}</strong>. Permissions
                will control each financial action as the platform grows.
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function Metric({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="card">
      <div className="metric-label">{label}</div>
      <div className="metric-value">{value}</div>
    </div>
  );
}

function Action({
  href,
  title,
  text,
}: {
  href: string;
  title: string;
  text: string;
}) {
  return (
    <Link className="action" href={href}>
      <strong>{title}</strong>

      <div className="metric-label" style={{ marginTop: 7 }}>
        {text}
      </div>
    </Link>
  );
}