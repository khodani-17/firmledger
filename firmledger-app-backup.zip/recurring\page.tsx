import Link from "next/link";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function Recurring() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "LAWYER",
    "ACCOUNTANT",
  ]);

  const rows = await prisma.recurringInvoice.findMany({
    where: { firmId: u.firmId },
    include: { client: true, matter: true },
    orderBy: { nextRunDate: "asc" },
  });

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="flex items-center justify-between gap-4">
            <h1 className="text-sm font-semibold tracking-tight text-slate-950">
              Recurring billing
            </h1>

            <Link
              href="/recurring/new"
              className="inline-flex h-9 items-center justify-center bg-slate-950 px-4 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              New recurring schedule
            </Link>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] px-6 py-2">
        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5">
            <span className="text-xs text-slate-500">
              {rows.length}{" "}
              {rows.length === 1
                ? "recurring schedule"
                : "recurring schedules"}
            </span>
          </div>

          {rows.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <p className="text-sm font-medium text-slate-900">
                No recurring billing schedules
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Create a recurring schedule to see it here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm table">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Client
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Description
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Frequency
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Next run
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Amount
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Status
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {rows.map((recurring) => (
                    <tr
                      key={recurring.id}
                      className="transition hover:bg-slate-50"
                    >
                      <td className="whitespace-nowrap px-3 py-2.5 font-medium text-slate-900">
                        {recurring.client.displayName}
                      </td>

                      <td className="max-w-[360px] px-3 py-2.5 text-slate-600">
                        <span className="block truncate">
                          {recurring.description}
                        </span>
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                        {recurring.frequency}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                        {recurring.nextRunDate.toLocaleDateString("en-ZA")}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right font-medium tabular-nums text-slate-900">
                        R{Number(recurring.subtotal).toFixed(2)} + VAT
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5">
                        <span className="badge">
                          {recurring.active ? "Active" : "Paused"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}