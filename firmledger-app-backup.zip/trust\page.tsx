import Link from "next/link";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

function clientName(client: {
  displayName: string | null;
  companyName: string | null;
  name: string | null;
  surname: string | null;
}) {
  return (
    client.displayName ||
    client.companyName ||
    [client.name, client.surname].filter(Boolean).join(" ") ||
    "Unallocated"
  );
}

function transactionEffect(type: string) {
  switch (type) {
    case "RECEIPT":
    case "INTEREST":
      return 1;
    case "PAYMENT":
    case "REFUND":
    case "FEE":
      return -1;
    case "REVERSAL":
      return 1;
    case "TRANSFER":
    case "ADJUSTMENT":
    default:
      return 0;
  }
}

export default async function Trust() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const [accounts, transactions, reconciliations] = await Promise.all([
    prisma.trustAccount.findMany({
      where: {
        firmId: u.firmId,
      },
      orderBy: {
        name: "asc",
      },
    }),

    prisma.trustTransaction.findMany({
      where: {
        firmId: u.firmId,
        status: "POSTED",
      },
      include: {
        client: {
          select: {
            displayName: true,
            companyName: true,
            name: true,
            surname: true,
          },
        },
        matter: {
          select: {
            matterNumber: true,
            title: true,
          },
        },
        trustAccount: {
          select: {
            id: true,
            name: true,
          },
        },
      },
      orderBy: {
        transactionDate: "desc",
      },
    }),

    prisma.trustReconciliation.findMany({
      where: {
        firmId: u.firmId,
      },
      include: {
        trustAccount: {
          select: {
            name: true,
          },
        },
      },
      orderBy: {
        reconciliationDate: "desc",
      },
      take: 10,
    }),
  ]);

  const accountBalances = accounts.map((account) => {
    const accountTransactions = transactions.filter(
      (transaction) => transaction.trustAccountId === account.id
    );

    const balance = accountTransactions.reduce(
      (sum, transaction) =>
        sum +
        Number(transaction.amount) *
          transactionEffect(transaction.type),
      0
    );

    return {
      ...account,
      balance,
      transactionCount: accountTransactions.length,
    };
  });

  const totalTrustBalance = accountBalances.reduce(
    (sum, account) => sum + account.balance,
    0
  );

  const clientMap = new Map<
    string,
    {
      name: string;
      balance: number;
    }
  >();

  for (const transaction of transactions) {
    const key =
      transaction.client?.displayName ||
      transaction.client?.companyName ||
      transaction.client?.name ||
      transaction.client?.surname ||
      "unallocated";

    const name = clientName(
      transaction.client ?? {
        displayName: null,
        companyName: null,
        name: null,
        surname: null,
      }
    );

    const current = clientMap.get(key) ?? {
      name,
      balance: 0,
    };

    current.balance +=
      Number(transaction.amount) *
      transactionEffect(transaction.type);

    clientMap.set(key, current);
  }

  const clientBalances = Array.from(clientMap.values())
    .filter((client) => Math.abs(client.balance) > 0.009)
    .sort((a, b) => b.balance - a.balance);

  const postedCount = transactions.length;

  const openReconciliations = reconciliations.filter(
    (reconciliation) =>
      reconciliation.status === "OPEN" ||
      reconciliation.status === "IN_PROGRESS"
  ).length;

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="flex items-center justify-between gap-4">
            <h1 className="text-sm font-semibold tracking-tight text-slate-950">
              Trust accounting
            </h1>

            <div className="flex items-center gap-2">
              <Link
                href="/trust/reconciliation"
                className="inline-flex h-9 items-center justify-center border border-slate-300 bg-white px-4 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
              >
                Reconcile
              </Link>

              <Link
                href="/trust/new"
                className="inline-flex h-9 items-center justify-center bg-slate-950 px-4 text-sm font-medium text-white transition hover:bg-slate-800"
              >
                New transaction
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] space-y-4 px-6 py-2">
        <section className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Trust balance
            </div>
            <div className="mt-1 text-sm font-semibold tabular-nums text-slate-950">
              R{" "}
              {totalTrustBalance.toLocaleString("en-ZA", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </div>
          </div>

          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Trust accounts
            </div>
            <div className="mt-1 text-sm font-semibold text-slate-950">
              {accounts.length}
            </div>
          </div>

          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Posted transactions
            </div>
            <div className="mt-1 text-sm font-semibold text-slate-950">
              {postedCount}
            </div>
          </div>

          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Open reconciliations
            </div>
            <div className="mt-1 text-sm font-semibold text-slate-950">
              {openReconciliations}
            </div>
          </div>
        </section>

        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5">
            <span className="text-xs font-medium text-slate-600">
              Trust bank accounts
            </span>
            <span className="text-xs text-slate-500">
              {accountBalances.length}{" "}
              {accountBalances.length === 1 ? "account" : "accounts"}
            </span>
          </div>

          {accountBalances.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <p className="text-sm font-medium text-slate-900">
                No trust accounts
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Create a trust account to begin recording trust transactions.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm table">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Account
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Bank
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Currency
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Transactions
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Balance
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {accountBalances.map((account) => (
                    <tr
                      key={account.id}
                      className="transition hover:bg-slate-50"
                    >
                      <td className="whitespace-nowrap px-3 py-2.5 font-medium text-slate-900">
                        {account.name}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                        {account.bankName || "—"}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                        {account.currency}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right tabular-nums text-slate-900">
                        {account.transactionCount}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right font-medium tabular-nums text-slate-900">
                        R{" "}
                        {account.balance.toLocaleString("en-ZA", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5">
            <span className="text-xs font-medium text-slate-600">
              Client trust balances
            </span>
            <span className="text-xs text-slate-500">
              {clientBalances.length}{" "}
              {clientBalances.length === 1 ? "client" : "clients"}
            </span>
          </div>

          {clientBalances.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <p className="text-sm font-medium text-slate-900">
                No client trust balances
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm table">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Client
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Trust balance
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {clientBalances.map((client) => (
                    <tr
                      key={client.name}
                      className="transition hover:bg-slate-50"
                    >
                      <td className="whitespace-nowrap px-3 py-2.5 font-medium text-slate-900">
                        {client.name}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right font-medium tabular-nums text-slate-900">
                        R{" "}
                        {client.balance.toLocaleString("en-ZA", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5">
            <span className="text-xs font-medium text-slate-600">
              Recent trust transactions
            </span>

            <Link
              href="/trust/new"
              className="text-xs font-semibold text-slate-600 hover:text-slate-950"
            >
              Record transaction →
            </Link>
          </div>

          {transactions.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <p className="text-sm font-medium text-slate-900">
                No posted trust transactions
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm table">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Date
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Account
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Client
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Matter
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Type
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Reference
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Amount
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {transactions.slice(0, 25).map((transaction) => (
                    <tr
                      key={transaction.id}
                      className="transition hover:bg-slate-50"
                    >
                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                        {new Date(
                          transaction.transactionDate
                        ).toLocaleDateString("en-ZA")}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-900">
                        {transaction.trustAccount.name}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-900">
                        {clientName(
                          transaction.client ?? {
                            displayName: null,
                            companyName: null,
                            name: null,
                            surname: null,
                          }
                        )}
                      </td>

                      <td className="max-w-[280px] px-3 py-2.5 text-slate-600">
                        <span className="block truncate">
                          {transaction.matter
                            ? `${transaction.matter.matterNumber} — ${transaction.matter.title}`
                            : "—"}
                        </span>
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5">
                        <span className="badge">{transaction.type}</span>
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                        {transaction.reference || "—"}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right font-medium tabular-nums text-slate-900">
                        R{" "}
                        {Number(transaction.amount).toLocaleString("en-ZA", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5">
            <span className="text-xs font-medium text-slate-600">
              Recent reconciliations
            </span>

            <Link
              href="/trust/reconciliation"
              className="text-xs font-semibold text-slate-600 hover:text-slate-950"
            >
              View reconciliations →
            </Link>
          </div>

          {reconciliations.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <p className="text-sm font-medium text-slate-900">
                No trust reconciliations
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm table">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Date
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Account
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Statement
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Ledger
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Difference
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Status
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {reconciliations.map((reconciliation) => (
                    <tr
                      key={reconciliation.id}
                      className="transition hover:bg-slate-50"
                    >
                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                        {new Date(
                          reconciliation.reconciliationDate
                        ).toLocaleDateString("en-ZA")}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-900">
                        {reconciliation.trustAccount.name}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right tabular-nums text-slate-900">
                        R{" "}
                        {Number(
                          reconciliation.statementBalance
                        ).toLocaleString("en-ZA", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right tabular-nums text-slate-900">
                        R{" "}
                        {Number(
                          reconciliation.ledgerBalance
                        ).toLocaleString("en-ZA", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right font-medium tabular-nums text-slate-900">
                        R{" "}
                        {Number(
                          reconciliation.difference
                        ).toLocaleString("en-ZA", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5">
                        <span className="badge">
                          {reconciliation.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}