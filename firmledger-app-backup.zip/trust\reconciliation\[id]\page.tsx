import Link from "next/link";
import { notFound } from "next/navigation";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";
import ReconciliationActions from "./reconciliation-actions";

function formatMoney(value: number) {
  return `R ${value.toLocaleString("en-ZA", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export default async function TrustReconciliationDetail({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const { id } = await params;

  const reconciliation =
    await prisma.trustReconciliation.findFirst({
      where: {
        id,
        firmId: u.firmId,
      },
      include: {
        trustAccount: true,
      },
    });

  if (!reconciliation) {
    notFound();
  }

  const difference = Number(reconciliation.difference);
  const balanced = Math.abs(difference) < 0.01;

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Link
                href="/trust/reconciliation"
                className="text-sm text-slate-500 transition hover:text-slate-900"
              >
                ← Reconciliation
              </Link>

              <span className="text-slate-300">/</span>

              <h1 className="text-sm font-semibold tracking-tight text-slate-950">
                Reconciliation detail
              </h1>
            </div>

            <Link
              href="/trust"
              className="inline-flex h-9 items-center justify-center border border-slate-300 bg-white px-4 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
            >
              Trust overview
            </Link>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] space-y-4 px-6 py-2">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
              Trust account
            </div>
            <div className="mt-1 truncate text-sm font-semibold text-slate-950">
              {reconciliation.trustAccount.name}
            </div>
          </div>

          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
              Statement balance
            </div>
            <div className="mt-1 text-sm font-semibold tabular-nums text-slate-950">
              {formatMoney(
                Number(reconciliation.statementBalance)
              )}
            </div>
          </div>

          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
              Ledger balance
            </div>
            <div className="mt-1 text-sm font-semibold tabular-nums text-slate-950">
              {formatMoney(
                Number(reconciliation.ledgerBalance)
              )}
            </div>
          </div>

          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
              Difference
            </div>
            <div className="mt-1 text-sm font-semibold tabular-nums text-slate-950">
              {formatMoney(difference)}
            </div>
          </div>
        </div>

        <section className="border border-slate-200 bg-white">
          <div className="border-b border-slate-200 px-4 py-2">
            <div className="flex items-center justify-between gap-4">
              <h2 className="text-sm font-semibold text-slate-900">
                Reconciliation details
              </h2>

              <span className="badge">
                {reconciliation.status}
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-sm table">
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <th className="w-56 bg-slate-50 px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Trust account
                  </th>
                  <td className="px-3 py-2.5 text-slate-900">
                    {reconciliation.trustAccount.name}
                  </td>
                </tr>

                <tr>
                  <th className="bg-slate-50 px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Bank
                  </th>
                  <td className="px-3 py-2.5 text-slate-700">
                    {reconciliation.trustAccount.bankName || "—"}
                  </td>
                </tr>

                <tr>
                  <th className="bg-slate-50 px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Account number
                  </th>
                  <td className="px-3 py-2.5 text-slate-700">
                    {reconciliation.trustAccount.accountNumber || "—"}
                  </td>
                </tr>

                <tr>
                  <th className="bg-slate-50 px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Reconciliation date
                  </th>
                  <td className="px-3 py-2.5 text-slate-700">
                    {new Date(
                      reconciliation.reconciliationDate
                    ).toLocaleDateString("en-ZA")}
                  </td>
                </tr>

                <tr>
                  <th className="bg-slate-50 px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Statement balance
                  </th>
                  <td className="px-3 py-2.5 text-right font-medium tabular-nums text-slate-900">
                    {formatMoney(
                      Number(reconciliation.statementBalance)
                    )}
                  </td>
                </tr>

                <tr>
                  <th className="bg-slate-50 px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Ledger balance
                  </th>
                  <td className="px-3 py-2.5 text-right font-medium tabular-nums text-slate-900">
                    {formatMoney(
                      Number(reconciliation.ledgerBalance)
                    )}
                  </td>
                </tr>

                <tr>
                  <th className="bg-slate-50 px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Difference
                  </th>
                  <td className="px-3 py-2.5 text-right font-semibold tabular-nums text-slate-950">
                    {formatMoney(difference)}
                  </td>
                </tr>

                <tr>
                  <th className="bg-slate-50 px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Result
                  </th>
                  <td className="px-3 py-2.5">
                    <span className="badge">
                      {balanced
                        ? "BALANCED"
                        : "DIFFERENCE REQUIRES INVESTIGATION"}
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        <section className="border border-slate-200 bg-white">
          <div className="border-b border-slate-200 px-4 py-2">
            <h2 className="text-sm font-semibold text-slate-900">
              Reconciliation controls
            </h2>
          </div>

          <div className="p-4">
            <ReconciliationActions
              reconciliationId={reconciliation.id}
              status={reconciliation.status}
              difference={difference}
              initialNotes={reconciliation.notes || ""}
            />
          </div>
        </section>
      </div>
    </main>
  );
}