import Link from "next/link";
import { createSupplierPayment } from "@/app/actions";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function PayPurchase() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const [suppliers, invoices, banks] = await Promise.all([
    prisma.supplier.findMany({
      where: {
        firmId: u.firmId,
        active: true,
      },
      orderBy: {
        name: "asc",
      },
    }),

    prisma.purchaseInvoice.findMany({
      where: {
        firmId: u.firmId,
        balanceDue: {
          gt: 0,
        },
        status: {
          not: "VOID",
        },
      },
      include: {
        supplier: true,
      },
      orderBy: {
        dueDate: "asc",
      },
    }),

    prisma.bankAccount.findMany({
      where: {
        firmId: u.firmId,
        active: true,
        isTrust: false,
      },
      orderBy: {
        name: "asc",
      },
    }),
  ]);

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          Firm<span>Ledger</span>
        </div>

        <Link className="nav-link" href="/purchases">
          ← Purchase invoices
        </Link>
      </aside>

      <main className="main">
        <section className="content">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "space-between",
              gap: "24px",
              marginBottom: "28px",
            }}
          >
            <div>
              <div
                className="metric-label"
                style={{
                  marginBottom: "8px",
                }}
              >
                ACCOUNTS PAYABLE
              </div>

              <h1
                className="page-title"
                style={{
                  marginBottom: "8px",
                }}
              >
                Pay supplier
              </h1>

              <p
                style={{
                  margin: 0,
                  color: "#667085",
                  fontSize: "14px",
                  lineHeight: 1.6,
                }}
              >
                Record a payment against a supplier invoice or make an
                unallocated supplier payment.
              </p>
            </div>

            <Link className="secondary-button" href="/purchases">
              Cancel
            </Link>
          </div>

          <form action={createSupplierPayment}>
            <div
              className="card"
              style={{
                padding: "28px",
                maxWidth: "950px",
              }}
            >
              {/* Payment details */}
              <div style={{ marginBottom: "24px" }}>
                <h2
                  style={{
                    margin: 0,
                    fontSize: "17px",
                    fontWeight: 650,
                  }}
                >
                  Payment details
                </h2>

                <p
                  style={{
                    margin: "6px 0 0",
                    color: "#667085",
                    fontSize: "13px",
                  }}
                >
                  Select the supplier, invoice and bank account used for the
                  payment.
                </p>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "minmax(0, 1fr) minmax(0, 1fr)",
                  gap: "22px",
                }}
              >
                <div>
                  <label
                    htmlFor="supplierId"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Supplier
                  </label>

                  <select
                    id="supplierId"
                    name="supplierId"
                    required
                    defaultValue=""
                    style={{
                      width: "100%",
                      minHeight: "46px",
                      padding: "0 14px",
                      border: "1px solid #d0d5dd",
                      borderRadius: "8px",
                      background: "#fff",
                      fontSize: "14px",
                      outline: "none",
                    }}
                  >
                    <option value="" disabled>
                      Select supplier
                    </option>

                    {suppliers.map((supplier) => (
                      <option key={supplier.id} value={supplier.id}>
                        {supplier.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="purchaseInvoiceId"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Purchase invoice
                  </label>

                  <select
                    id="purchaseInvoiceId"
                    name="purchaseInvoiceId"
                    defaultValue=""
                    style={{
                      width: "100%",
                      minHeight: "46px",
                      padding: "0 14px",
                      border: "1px solid #d0d5dd",
                      borderRadius: "8px",
                      background: "#fff",
                      fontSize: "14px",
                      outline: "none",
                    }}
                  >
                    <option value="">
                      Unallocated supplier payment
                    </option>

                    {invoices.map((invoice) => (
                      <option
                        key={invoice.id}
                        value={invoice.id}
                      >
                        {invoice.invoiceNumber} · {invoice.supplier.name} · R
                        {Number(invoice.balanceDue).toFixed(2)}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div style={{ marginTop: "22px" }}>
                <label
                  htmlFor="bankAccountId"
                  style={{
                    display: "block",
                    fontSize: "13px",
                    fontWeight: 600,
                    marginBottom: "8px",
                  }}
                >
                  Business bank account
                </label>

                <select
                  id="bankAccountId"
                  name="bankAccountId"
                  required
                  defaultValue=""
                  style={{
                    width: "100%",
                    minHeight: "46px",
                    padding: "0 14px",
                    border: "1px solid #d0d5dd",
                    borderRadius: "8px",
                    background: "#fff",
                    fontSize: "14px",
                    outline: "none",
                  }}
                >
                  <option value="" disabled>
                    Select bank account
                  </option>

                  {banks.map((bank) => (
                    <option key={bank.id} value={bank.id}>
                      {bank.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Amount */}
              <div
                style={{
                  height: "1px",
                  background: "#eaecf0",
                  margin: "30px 0",
                }}
              />

              <div style={{ marginBottom: "22px" }}>
                <h2
                  style={{
                    margin: 0,
                    fontSize: "17px",
                    fontWeight: 650,
                  }}
                >
                  Payment amount
                </h2>

                <p
                  style={{
                    margin: "6px 0 0",
                    color: "#667085",
                    fontSize: "13px",
                  }}
                >
                  Enter the amount paid to the supplier.
                </p>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "minmax(0, 1fr) minmax(0, 1fr)",
                  gap: "22px",
                }}
              >
                <div>
                  <label
                    htmlFor="amount"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Amount
                  </label>

                  <div
                    style={{
                      position: "relative",
                    }}
                  >
                    <span
                      style={{
                        position: "absolute",
                        left: "14px",
                        top: "50%",
                        transform: "translateY(-50%)",
                        color: "#667085",
                        fontSize: "14px",
                        pointerEvents: "none",
                      }}
                    >
                      R
                    </span>

                    <input
                      id="amount"
                      name="amount"
                      type="number"
                      min="0.01"
                      step="0.01"
                      required
                      placeholder="0.00"
                      style={{
                        width: "100%",
                        minHeight: "46px",
                        padding: "0 14px 0 32px",
                        border: "1px solid #d0d5dd",
                        borderRadius: "8px",
                        background: "#fff",
                        fontSize: "14px",
                        outline: "none",
                      }}
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="reference"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Payment reference
                  </label>

                  <input
                    id="reference"
                    name="reference"
                    required
                    placeholder="e.g. SUP-PAY-001"
                    style={{
                      width: "100%",
                      minHeight: "46px",
                      padding: "0 14px",
                      border: "1px solid #d0d5dd",
                      borderRadius: "8px",
                      background: "#fff",
                      fontSize: "14px",
                      outline: "none",
                    }}
                  />
                </div>
              </div>

              {/* Payment summary */}
              <div
                style={{
                  marginTop: "28px",
                  padding: "18px 20px",
                  borderRadius: "8px",
                  background: "#f8f9fb",
                  border: "1px solid #eaecf0",
                }}
              >
                <div
                  style={{
                    fontSize: "13px",
                    color: "#667085",
                    marginBottom: "5px",
                  }}
                >
                  Payment summary
                </div>

                <div
                  style={{
                    fontSize: "13px",
                    color: "#98a2b3",
                    lineHeight: 1.6,
                  }}
                >
                  The payment will be posted to the supplier's accounts
                  payable balance and the selected business bank account.
                </div>
              </div>

              {/* Actions */}
              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "12px",
                  marginTop: "30px",
                  paddingTop: "22px",
                  borderTop: "1px solid #eaecf0",
                }}
              >
                <Link className="secondary-button" href="/purchases">
                  Cancel
                </Link>

                <button
                  className="primary-button"
                  type="submit"
                >
                  Record supplier payment
                </button>
              </div>
            </div>
          </form>
        </section>
      </main>
    </div>
  );
}