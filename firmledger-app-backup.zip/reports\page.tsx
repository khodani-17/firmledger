import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function Reports() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const [lines, invoices, expenses, payments] = await Promise.all([
    prisma.journalLine.findMany({
      where: {
        journalEntry: {
          firmId: u.firmId,
        },
      },
      include: {
        ledgerAccount: true,
        journalEntry: true,
      },
    }),

    prisma.invoice.findMany({
      where: {
        firmId: u.firmId,
      },
      select: {
        total: true,
        amountPaid: true,
        balanceDue: true,
      },
    }),

    prisma.expense.findMany({
      where: {
        firmId: u.firmId,
        status: {
          not: "REJECTED",
        },
      },
      select: {
        amount: true,
        taxAmount: true,
      },
    }),

    prisma.payment.findMany({
      where: {
        firmId: u.firmId,
        status: "COMPLETED",
      },
      select: {
        amount: true,
      },
    }),
  ]);

  const accountTotals = new Map<
    string,
    {
      name: string;
      debit: number;
      credit: number;
      type: string;
    }
  >();

  for (const line of lines) {
    const current = accountTotals.get(line.ledgerAccountId) || {
      name: line.ledgerAccount.name,
      debit: 0,
      credit: 0,
      type: line.ledgerAccount.accountType ?? "",
    };

    current.debit += Number(line.debit);
    current.credit += Number(line.credit);

    accountTotals.set(line.ledgerAccountId, current);
  }

  const revenue = [...accountTotals.values()]
    .filter((account) => account.type === "REVENUE")
    .reduce((sum, account) => sum + account.credit - account.debit, 0);

  const operatingExpenses = [...accountTotals.values()]
    .filter((account) => account.type === "EXPENSE")
    .reduce((sum, account) => sum + account.debit - account.credit, 0);

  const receivables = invoices.reduce(
    (sum, invoice) => sum + Number(invoice.balanceDue),
    0
  );

  const receipts = payments.reduce(
    (sum, payment) => sum + Number(payment.amount),
    0
  );

  const expensesTotal = expenses.reduce(
    (sum, expense) =>
      sum + Number(expense.amount) + Number(expense.taxAmount),
    0
  );

  const accounts = [...accountTotals.values()].sort((a, b) =>
    a.name.localeCompare(b.name)
  );

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <h1 className="text-sm font-semibold tracking-tight text-slate-950">
            Financial reports
          </h1>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] space-y-4 px-6 py-2">
        <section className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Revenue
            </div>
            <div className="mt-1 text-sm font-semibold tabular-nums text-slate-950">
              R{revenue.toFixed(2)}
            </div>
          </div>

          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Operating expenses
            </div>
            <div className="mt-1 text-sm font-semibold tabular-nums text-slate-950">
              R{operatingExpenses.toFixed(2)}
            </div>
          </div>

          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Net result
            </div>
            <div className="mt-1 text-sm font-semibold tabular-nums text-slate-950">
              R{(revenue - operatingExpenses).toFixed(2)}
            </div>
          </div>

          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
              Accounts receivable
            </div>
            <div className="mt-1 text-sm font-semibold tabular-nums text-slate-950">
              R{receivables.toFixed(2)}
            </div>
          </div>
        </section>

        <section className="grid grid-cols-1 gap-3 md:grid-cols-2">
          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-xs font-medium text-slate-600">
              Cash receipts
            </div>
            <div className="mt-1 text-base font-semibold tabular-nums text-slate-950">
              R{receipts.toFixed(2)}
            </div>
          </div>

          <div className="border border-slate-200 bg-white px-4 py-2">
            <div className="text-xs font-medium text-slate-600">
              Expense cash outflow
            </div>
            <div className="mt-1 text-base font-semibold tabular-nums text-slate-950">
              R{expensesTotal.toFixed(2)}
            </div>
          </div>
        </section>

        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5">
            <span className="text-xs font-medium text-slate-600">
              Trial balance
            </span>
            <span className="text-xs text-slate-500">
              {accounts.length}{" "}
              {accounts.length === 1 ? "account" : "accounts"}
            </span>
          </div>

          {accounts.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <p className="text-sm font-medium text-slate-900">
                No accounting activity
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Posted journal entries will appear here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm table">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Account
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Type
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Debit
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Credit
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Balance
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {accounts.map((account) => {
                    const balance = account.debit - account.credit;

                    return (
                      <tr
                        key={account.name}
                        className="transition hover:bg-slate-50"
                      >
                        <td className="whitespace-nowrap px-3 py-2.5 font-medium text-slate-900">
                          {account.name}
                        </td>

                        <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                          {account.type}
                        </td>

                        <td className="whitespace-nowrap px-3 py-2.5 text-right tabular-nums text-slate-900">
                          R{account.debit.toFixed(2)}
                        </td>

                        <td className="whitespace-nowrap px-3 py-2.5 text-right tabular-nums text-slate-900">
                          R{account.credit.toFixed(2)}
                        </td>

                        <td className="whitespace-nowrap px-3 py-2.5 text-right font-medium tabular-nums text-slate-900">
                          R{Math.abs(balance).toFixed(2)}{" "}
                          {balance >= 0 ? "Dr" : "Cr"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}