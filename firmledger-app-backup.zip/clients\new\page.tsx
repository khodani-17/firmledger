import { createClient } from "@/app/actions";
import { requireRole } from "@/lib/permissions";

export default async function NewClient() {
  await requireRole(["OWNER", "ADMIN", "FINANCE", "LAWYER", "STAFF"]);
  return <Form title="New client" action={createClient} fields={[
    ["displayName","Client name","text"],["email","Email","email"],["phone","Phone","tel"]
  ]} select />;
}
function Form({title,action,fields,select}:{title:string;action:(d:FormData)=>Promise<void>;fields:string[][];select:boolean}) { return <div className="shell"><aside className="sidebar"><div className="brand">Firm<span>Ledger</span></div><a className="nav-link" href="/clients">← Clients</a></aside><main className="main"><header className="topbar"><strong>Client management</strong></header><section className="content"><h1 className="page-title">{title}</h1><p className="page-subtitle">Capture only the information the firm needs.</p><div className="card form-card"><form action={action}>{fields.map(([n,l,t])=><label key={n}>{l}<input name={n} type={t} required={n==='displayName'}/></label>)}{select&&<label>Client type<select name="type" defaultValue="INDIVIDUAL"><option value="INDIVIDUAL">Individual</option><option value="COMPANY">Company</option><option value="TRUST">Trust</option><option value="OTHER">Other</option></select></label>}<button className="primary-button">Create client</button></form></div></section></main></div> }
