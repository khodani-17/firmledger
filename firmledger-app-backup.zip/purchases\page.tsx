import Link from "next/link";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function Purchases() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const rows = await prisma.purchaseInvoice.findMany({
    where: { firmId: u.firmId },
    include: { supplier: true, matter: true },
    orderBy: { invoiceDate: "desc" },
  });

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="flex items-center justify-between gap-4">
            <h1 className="text-sm font-semibold tracking-tight text-slate-950">
              Purchase invoices
            </h1>

            <div className="flex items-center gap-2">
              <Link
                href="/purchases/pay"
                className="inline-flex h-9 items-center justify-center border border-slate-300 bg-white px-4 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
              >
                Pay supplier
              </Link>

              <Link
                href="/purchases/new"
                className="inline-flex h-9 items-center justify-center bg-slate-950 px-4 text-sm font-medium text-white transition hover:bg-slate-800"
              >
                New purchase invoice
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] px-6 py-2">
        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5">
            <span className="text-xs text-slate-500">
              {rows.length}{" "}
              {rows.length === 1 ? "purchase invoice" : "purchase invoices"}
            </span>
          </div>

          {rows.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <p className="text-sm font-medium text-slate-900">
                No purchase invoices
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Create a purchase invoice to see it here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm table">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Supplier
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Invoice
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Date
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Status
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Total
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Balance
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {rows.map((purchase) => (
                    <tr
                      key={purchase.id}
                      className="transition hover:bg-slate-50"
                    >
                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-900">
                        {purchase.supplier.name}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 font-medium text-slate-900">
                        {purchase.invoiceNumber}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                        {purchase.invoiceDate.toLocaleDateString("en-ZA")}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5">
                        <span className="badge">{purchase.status}</span>
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right font-medium tabular-nums text-slate-900">
                        R{Number(purchase.total).toFixed(2)}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right font-medium tabular-nums text-slate-900">
                        R{Number(purchase.balanceDue).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}