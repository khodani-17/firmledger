import Link from "next/link";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";
import { createTrustReconciliation } from "./actions";

export default async function NewTrustReconciliation() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const accounts = await prisma.trustAccount.findMany({
    where: {
      firmId: u.firmId,
      active: true,
    },
    orderBy: {
      name: "asc",
    },
  });

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Link
                href="/trust/reconciliation"
                className="text-sm text-slate-500 transition hover:text-slate-900"
              >
                ← Reconciliation
              </Link>

              <span className="text-slate-300">/</span>

              <h1 className="text-sm font-semibold tracking-tight text-slate-950">
                New reconciliation
              </h1>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[900px] px-6 py-2">
        <section className="border border-slate-200 bg-white">
          <div className="border-b border-slate-200 px-4 py-2">
            <h2 className="text-sm font-semibold text-slate-900">
              Reconciliation details
            </h2>
          </div>

          {accounts.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <p className="text-sm font-medium text-slate-900">
                No active trust accounts
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Create a trust account before starting a reconciliation.
              </p>
              <Link
                href="/trust/new"
                className="mt-4 inline-flex h-9 items-center justify-center bg-slate-950 px-4 text-sm font-medium text-white transition hover:bg-slate-800"
              >
                Create trust account
              </Link>
            </div>
          ) : (
            <form
              action={createTrustReconciliation}
              className="form-grid p-4"
            >
              <div className="form-field">
                <label htmlFor="trustAccountId">
                  Trust account
                </label>

                <select
                  id="trustAccountId"
                  name="trustAccountId"
                  required
                  defaultValue=""
                >
                  <option value="" disabled>
                    Select trust account
                  </option>

                  {accounts.map((account) => (
                    <option key={account.id} value={account.id}>
                      {account.name}
                      {account.bankName
                        ? ` — ${account.bankName}`
                        : ""}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-field">
                <label htmlFor="reconciliationDate">
                  Reconciliation date
                </label>

                <input
                  id="reconciliationDate"
                  name="reconciliationDate"
                  type="date"
                  required
                />
              </div>

              <div className="form-field">
                <label htmlFor="statementBalance">
                  Bank statement balance
                </label>

                <input
                  id="statementBalance"
                  name="statementBalance"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  required
                />

                <small>
                  Enter the closing balance shown on the trust bank
                  statement.
                </small>
              </div>

              <div className="form-field form-field-full">
                <label htmlFor="notes">Notes</label>

                <textarea
                  id="notes"
                  name="notes"
                  rows={3}
                  placeholder="Optional reconciliation notes..."
                />
              </div>

              <div className="form-field form-field-full">
                <div className="border border-slate-200 bg-slate-50 px-4 py-2">
                  <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                    Ledger balance
                  </div>

                  <p className="mt-1 text-xs leading-5 text-slate-600">
                    FirmLedger calculates the ledger balance automatically
                    from POSTED trust transactions up to the reconciliation
                    date.
                  </p>
                </div>
              </div>

              <div className="form-actions form-field-full">
                <Link
                  className="button"
                  href="/trust/reconciliation"
                >
                  Cancel
                </Link>

                <button
                  className="button primary"
                  type="submit"
                >
                  Create reconciliation
                </button>
              </div>
            </form>
          )}
        </section>
      </div>
    </main>
  );
}