import Link from "next/link";
import { requireUser } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function MattersPage() {
  const user = await requireUser();

  const matters = await prisma.matter.findMany({
    where: {
      firmId: user.firmId,
    },
    include: {
      client: true,
    },
    orderBy: {
      matterNumber: "desc",
    },
  });

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="flex items-center justify-between gap-4">
            <h1 className="text-sm font-semibold tracking-tight text-slate-950">
              Matters
            </h1>

            <Link
              className="inline-flex h-9 items-center justify-center bg-slate-950 px-4 text-sm font-medium text-white transition hover:bg-slate-800"
              href="/matters/new"
            >
              New matter
            </Link>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] px-6 py-2">
        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2">
            <span className="text-xs text-slate-500">
              {matters.length}{" "}
              {matters.length === 1 ? "matter" : "matters"}
            </span>
          </div>

          {matters.length === 0 ? (
            <div className="px-4 py-6 text-center">
              <p className="text-sm font-medium text-slate-900">
                No matters found
              </p>

              <p className="mt-1 text-xs text-slate-500">
                Create a matter to see it here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Matter</th>
                    <th>Client</th>
                    <th>Status</th>
                    <th>Opened</th>
                  </tr>
                </thead>

                <tbody>
                  {matters.map((matter) => (
                    <tr key={matter.id}>
                      <td>
                        <strong>{matter.matterNumber}</strong>
                        <br />
                        <span className="metric-label">
                          {matter.title}
                        </span>
                      </td>

                      <td>{matter.client.displayName}</td>

                      <td>
                        <span className="badge">
                          {matter.status}
                        </span>
                      </td>

                      <td>
                        {matter.openedAt.toLocaleDateString("en-ZA")}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}