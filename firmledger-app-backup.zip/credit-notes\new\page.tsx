import Link from "next/link";
import { createCreditNote } from "@/app/actions";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function NewCredit() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const [clients, invoices] = await Promise.all([
    prisma.client.findMany({
      where: {
        firmId: u.firmId,
        active: true,
      },
      orderBy: {
        displayName: "asc",
      },
    }),

    prisma.invoice.findMany({
      where: {
        firmId: u.firmId,
        status: {
          not: "VOID",
        },
      },
      include: {
        client: true,
      },
      orderBy: {
        issueDate: "desc",
      },
      take: 200,
    }),
  ]);

  return (
    <main className="min-h-screen bg-[var(--app-bg)]">
      <div className="border-b border-[var(--border)] bg-[var(--surface)]">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="page-header">
            <div>
              <h1 className="page-title">
                New credit note
              </h1>

              <p className="page-subtitle">
                Create a credit note against a client or
                existing invoice.
              </p>
            </div>

            <div className="page-actions">
              <Link
                href="/credit-notes"
                className="secondary-button"
              >
                ← Credit notes
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1100px] px-6 py-5">
        <form action={createCreditNote}>
          <section className="card compact-card">
            <div className="section-header">
              <div>
                <div className="section-title">
                  Credit note details
                </div>

                <div className="metric-label">
                  Select the client, invoice and reason for
                  the credit.
                </div>
              </div>
            </div>

            <div className="form-grid">
              <label>
                Client
                <select name="clientId" required>
                  <option value="">
                    Select client
                  </option>

                  {clients.map((client) => (
                    <option
                      key={client.id}
                      value={client.id}
                    >
                      {client.displayName}
                    </option>
                  ))}
                </select>
              </label>

              <label>
                Invoice
                <select name="invoiceId">
                  <option value="">
                    No invoice
                  </option>

                  {invoices.map((invoice) => (
                    <option
                      key={invoice.id}
                      value={invoice.id}
                    >
                      {invoice.invoiceNumber} ·{" "}
                      {invoice.client.displayName} · R
                      {Number(
                        invoice.balanceDue,
                      ).toFixed(2)}
                    </option>
                  ))}
                </select>
              </label>

              <label className="full-width">
                Reason
                <input
                  name="reason"
                  required
                  placeholder="Reason for issuing the credit note"
                />
              </label>
            </div>
          </section>

          <section className="card compact-card">
            <div className="section-header">
              <div>
                <div className="section-title">
                  Credit amount
                </div>

                <div className="metric-label">
                  Enter the amount being credited.
                </div>
              </div>
            </div>

            <div className="form-grid form-grid-two">
              <label>
                Subtotal
                <input
                  name="subtotal"
                  type="number"
                  min="0.01"
                  step="0.01"
                  required
                  placeholder="0.00"
                />
              </label>

              <label>
                VAT amount
                <input
                  name="taxAmount"
                  type="number"
                  min="0"
                  step="0.01"
                  defaultValue="0"
                  placeholder="0.00"
                />
              </label>
            </div>
          </section>

          <div className="form-actions">
            <Link
              href="/credit-notes"
              className="secondary-button"
            >
              Cancel
            </Link>

            <button
              type="submit"
              className="primary-button"
            >
              Create credit note
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}
