import Link from "next/link";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

type SearchParams = {
  asAt?: string;
  periodId?: string;
};

type BalanceAccount = {
  id: string;
  code: string;
  name: string;
  amount: number;
};

function money(amount: number, currency = "ZAR") {
  return new Intl.NumberFormat("en-ZA", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(amount);
}

function decimal(value: unknown) {
  return Number(value ?? 0);
}

function toDate(value?: string) {
  if (!value) return undefined;

  const date = new Date(`${value}T23:59:59.999`);

  return Number.isNaN(date.getTime()) ? undefined : date;
}

function dateInputValue(date: Date) {
  return date.toISOString().slice(0, 10);
}

function formatDate(date: Date) {
  return new Intl.DateTimeFormat("en-ZA", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(date);
}

export default async function BalanceSheetPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const user = await requireRole(["OWNER", "ADMIN", "FINANCE"]);

  const params = await searchParams;

  const periods = await prisma.financialPeriod.findMany({
    where: {
      firmId: user.firmId,
    },
    orderBy: {
      startDate: "desc",
    },
    select: {
      id: true,
      name: true,
      startDate: true,
      endDate: true,
      status: true,
    },
  });

  const selectedPeriod =
    periods.find((period) => period.id === params.periodId) ?? null;

  const asAt =
    toDate(params.asAt) ??
    selectedPeriod?.endDate ??
    new Date();

  const journalLines = await prisma.journalLine.findMany({
    where: {
      ledgerAccount: {
        firmId: user.firmId,
        active: true,
      },
      journalEntry: {
        firmId: user.firmId,
        entryDate: {
          lte: asAt,
        },
      },
    },
    select: {
      ledgerAccountId: true,
      debit: true,
      credit: true,
      ledgerAccount: {
        select: {
          id: true,
          code: true,
          name: true,
          accountType: true,
          type: true,
        },
      },
    },
  });

  const assetMap = new Map<string, BalanceAccount>();
  const liabilityMap = new Map<string, BalanceAccount>();
  const equityMap = new Map<string, BalanceAccount>();

  let revenueBalance = 0;
  let expenseBalance = 0;

  for (const line of journalLines) {
    const account = line.ledgerAccount;

    const debit = decimal(line.debit);
    const credit = decimal(line.credit);

    const accountType = account.accountType ?? account.type;

    if (accountType === "ASSET") {
      const existing = assetMap.get(account.id);

      assetMap.set(account.id, {
        id: account.id,
        code: account.code,
        name: account.name,
        amount: (existing?.amount ?? 0) + debit - credit,
      });
    }

    if (accountType === "LIABILITY") {
      const existing = liabilityMap.get(account.id);

      liabilityMap.set(account.id, {
        id: account.id,
        code: account.code,
        name: account.name,
        amount: (existing?.amount ?? 0) + credit - debit,
      });
    }

    if (accountType === "EQUITY") {
      const existing = equityMap.get(account.id);

      equityMap.set(account.id, {
        id: account.id,
        code: account.code,
        name: account.name,
        amount: (existing?.amount ?? 0) + credit - debit,
      });
    }

    if (accountType === "REVENUE") {
      revenueBalance += credit - debit;
    }

    if (accountType === "EXPENSE") {
      expenseBalance += debit - credit;
    }
  }

  const assets = Array.from(assetMap.values())
    .filter((account) => Math.abs(account.amount) >= 0.005)
    .sort((a, b) => a.code.localeCompare(b.code));

  const liabilities = Array.from(liabilityMap.values())
    .filter((account) => Math.abs(account.amount) >= 0.005)
    .sort((a, b) => a.code.localeCompare(b.code));

  const equityAccounts = Array.from(equityMap.values())
    .filter((account) => Math.abs(account.amount) >= 0.005)
    .sort((a, b) => a.code.localeCompare(b.code));

  const totalAssets = assets.reduce(
    (sum, account) => sum + account.amount,
    0,
  );

  const totalLiabilities = liabilities.reduce(
    (sum, account) => sum + account.amount,
    0,
  );

  const totalEquityAccounts = equityAccounts.reduce(
    (sum, account) => sum + account.amount,
    0,
  );

  /*
   * Current-period/accumulated result:
   *
   * Revenue - Expenses = Profit
   *
   * Profit increases equity.
   */
  const retainedResult = revenueBalance - expenseBalance;

  const totalEquity = totalEquityAccounts + retainedResult;

  const liabilitiesAndEquity = totalLiabilities + totalEquity;

  const difference = totalAssets - liabilitiesAndEquity;

  const isBalanced = Math.abs(difference) < 0.01;

  const currency = "ZAR";

  return (
    <main className="min-h-screen bg-slate-950 text-slate-100">
      <div className="mx-auto max-w-[1400px] px-4 py-6 sm:px-6 lg:px-8">
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <div className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">
              Accounting
            </div>

            <h1 className="text-2xl font-semibold tracking-tight">
              Balance Sheet
            </h1>

            <p className="mt-1 text-sm text-slate-400">
              Financial position of the firm at a selected date.
            </p>
          </div>

          <Link
            href="/accounting/profit-loss"
            className="inline-flex items-center justify-center rounded-lg border border-slate-700 bg-slate-900 px-4 py-2 text-sm font-medium text-slate-200 transition hover:bg-slate-800"
          >
            Profit &amp; Loss
          </Link>
        </div>

        <form
          method="get"
          className="mb-5 grid gap-3 rounded-xl border border-slate-800 bg-slate-900/70 p-4 md:grid-cols-[1.4fr_1fr_auto]"
        >
          <div>
            <label
              htmlFor="periodId"
              className="mb-1.5 block text-xs font-medium text-slate-400"
            >
              Financial period
            </label>

            <select
              id="periodId"
              name="periodId"
              defaultValue={selectedPeriod?.id ?? ""}
              className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100 outline-none focus:border-slate-500"
            >
              <option value="">Custom / as-at date</option>

              {periods.map((period) => (
                <option key={period.id} value={period.id}>
                  {period.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="asAt"
              className="mb-1.5 block text-xs font-medium text-slate-400"
            >
              As at
            </label>

            <input
              id="asAt"
              name="asAt"
              type="date"
              defaultValue={
                params.asAt
                  ? params.asAt
                  : dateInputValue(asAt)
              }
              className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100 outline-none focus:border-slate-500"
            />
          </div>

          <button
            type="submit"
            className="self-end rounded-lg bg-slate-100 px-5 py-2 text-sm font-semibold text-slate-950 transition hover:bg-white"
          >
            Apply
          </button>
        </form>

        <section className="mb-5 grid gap-3 sm:grid-cols-3">
          <SummaryCard
            label="Total assets"
            value={money(totalAssets, currency)}
          />

          <SummaryCard
            label="Total liabilities"
            value={money(totalLiabilities, currency)}
          />

          <SummaryCard
            label="Total equity"
            value={money(totalEquity, currency)}
          />
        </section>

        <section
          className={`mb-5 rounded-xl border p-4 ${
            isBalanced
              ? "border-emerald-900/60 bg-emerald-950/20"
              : "border-amber-900/60 bg-amber-950/20"
          }`}
        >
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
                Accounting equation
              </div>

              <div className="mt-1 text-sm text-slate-300">
                Assets = Liabilities + Equity
              </div>
            </div>

            <div className="text-left sm:text-right">
              <div
                className={`text-sm font-semibold ${
                  isBalanced
                    ? "text-emerald-300"
                    : "text-amber-300"
                }`}
              >
                {isBalanced
                  ? "Balanced"
                  : "Out of balance"}
              </div>

              <div className="mt-1 text-xs text-slate-500">
                Difference: {money(Math.abs(difference), currency)}
              </div>
            </div>
          </div>
        </section>

        <section className="mb-5 rounded-xl border border-slate-800 bg-slate-900 p-4">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
                Reporting date
              </div>

              <div className="mt-1 text-sm font-medium text-slate-200">
                {formatDate(asAt)}
              </div>
            </div>

            {selectedPeriod && (
              <div className="text-xs text-slate-500">
                {selectedPeriod.name} · {selectedPeriod.status}
              </div>
            )}
          </div>
        </section>

        <div className="grid gap-5 lg:grid-cols-2">
          <ReportSection
            title="Assets"
            description="Resources controlled by the firm."
            accounts={assets}
            total={totalAssets}
            currency={currency}
          />

          <div className="space-y-5">
            <ReportSection
              title="Liabilities"
              description="Obligations owed by the firm."
              accounts={liabilities}
              total={totalLiabilities}
              currency={currency}
            />

            <section className="overflow-hidden rounded-xl border border-slate-800 bg-slate-900">
              <div className="border-b border-slate-800 px-4 py-2">
                <h2 className="text-sm font-semibold text-slate-100">
                  Equity
                </h2>

                <p className="mt-1 text-xs text-slate-500">
                  Owners&apos; equity and accumulated financial result.
                </p>
              </div>

              {equityAccounts.length === 0 && Math.abs(retainedResult) < 0.005 ? (
                <div className="px-5 py-6 text-center">
                  <div className="text-sm font-medium text-slate-300">
                    No equity activity recorded
                  </div>

                  <p className="mt-1 text-xs text-slate-500">
                    No equity or accumulated result was found for this date.
                  </p>
                </div>
              ) : (
                <>
                  <div className="divide-y divide-slate-800">
                    {equityAccounts.map((account) => (
                      <div
                        key={account.id}
                        className="flex items-center justify-between gap-4 px-4 py-2"
                      >
                        <div className="min-w-0">
                          <div className="text-sm font-medium text-slate-200">
                            {account.name}
                          </div>

                          <div className="mt-0.5 text-xs text-slate-500">
                            {account.code}
                          </div>
                        </div>

                        <div className="whitespace-nowrap text-sm font-medium text-slate-300">
                          {money(account.amount, currency)}
                        </div>
                      </div>
                    ))}

                    {Math.abs(retainedResult) >= 0.005 && (
                      <div className="flex items-center justify-between gap-4 px-4 py-2">
                        <div>
                          <div className="text-sm font-medium text-slate-200">
                            Accumulated result
                          </div>

                          <div className="mt-0.5 text-xs text-slate-500">
                            Revenue less expenses
                          </div>
                        </div>

                        <div className="whitespace-nowrap text-sm font-medium text-slate-300">
                          {money(retainedResult, currency)}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between border-t border-slate-700 bg-slate-950/40 px-4 py-2">
                    <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                      Total equity
                    </span>

                    <span className="text-sm font-semibold text-slate-100">
                      {money(totalEquity, currency)}
                    </span>
                  </div>
                </>
              )}
            </section>
          </div>
        </div>

        <section className="mt-5 rounded-xl border border-slate-800 bg-slate-900 p-5">
          <div className="grid gap-4 sm:grid-cols-3">
            <ResultLine
              label="Total assets"
              value={money(totalAssets, currency)}
            />

            <ResultLine
              label="Liabilities + equity"
              value={money(
                liabilitiesAndEquity,
                currency,
              )}
            />

            <ResultLine
              label="Difference"
              value={money(
                Math.abs(difference),
                currency,
              )}
            />
          </div>
        </section>

        <div className="mt-4 text-xs leading-5 text-slate-600">
          This report is calculated from journal lines classified as Assets,
          Liabilities, Equity, Revenue, and Expenses. The accumulated result
          is included in equity so that the accounting equation can be tested
          against the ledger.
        </div>
      </div>
    </main>
  );
}

function SummaryCard({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
      <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
        {label}
      </div>

      <div className="mt-2 text-sm font-semibold tracking-tight text-slate-100">
        {value}
      </div>
    </div>
  );
}

function ReportSection({
  title,
  description,
  accounts,
  total,
  currency,
}: {
  title: string;
  description: string;
  accounts: BalanceAccount[];
  total: number;
  currency: string;
}) {
  return (
    <section className="overflow-hidden rounded-xl border border-slate-800 bg-slate-900">
      <div className="border-b border-slate-800 px-4 py-2">
        <h2 className="text-sm font-semibold text-slate-100">
          {title}
        </h2>

        <p className="mt-1 text-xs text-slate-500">
          {description}
        </p>
      </div>

      {accounts.length === 0 ? (
        <div className="px-5 py-6 text-center">
          <div className="text-sm font-medium text-slate-300">
            No {title.toLowerCase()} recorded
          </div>

          <p className="mt-1 text-xs text-slate-500">
            No posted journal activity was found for this date.
          </p>
        </div>
      ) : (
        <>
          <div className="divide-y divide-slate-800">
            {accounts.map((account) => (
              <div
                key={account.id}
                className="flex items-center justify-between gap-4 px-4 py-2"
              >
                <div className="min-w-0">
                  <div className="text-sm font-medium text-slate-200">
                    {account.name}
                  </div>

                  <div className="mt-0.5 text-xs text-slate-500">
                    {account.code}
                  </div>
                </div>

                <div className="whitespace-nowrap text-sm font-medium text-slate-300">
                  {money(account.amount, currency)}
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between border-t border-slate-700 bg-slate-950/40 px-4 py-2">
            <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">
              Total {title}
            </span>

            <span className="text-sm font-semibold text-slate-100">
              {money(total, currency)}
            </span>
          </div>
        </>
      )}
    </section>
  );
}

function ResultLine({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div>
      <div className="text-xs text-slate-500">{label}</div>

      <div className="mt-1 text-sm font-semibold text-slate-200">
        {value}
      </div>
    </div>
  );
}