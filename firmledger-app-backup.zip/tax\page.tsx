import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";
import { createTaxReturn } from "@/app/actions";

export default async function Tax() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const rows = await prisma.taxReturn.findMany({
    where: { firmId: u.firmId },
    orderBy: { periodEnd: "desc" },
  });

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <h1 className="text-sm font-semibold tracking-tight text-slate-950">
            VAT & tax
          </h1>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] space-y-4 px-6 py-2">
        <section className="border border-slate-200 bg-white">
          <div className="border-b border-slate-200 px-4 py-2.5">
            <span className="text-xs font-medium text-slate-600">
              Prepare tax return
            </span>
          </div>

          <form
            action={createTaxReturn}
            className="grid grid-cols-1 gap-3 p-4 md:grid-cols-4"
          >
            <label className="block">
              <span className="mb-1 block text-[11px] font-medium text-slate-600">
                Return type
              </span>
              <select
                name="returnType"
                className="h-9 w-full border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-slate-700 focus:ring-1 focus:ring-slate-700"
              >
                <option>VAT201</option>
                <option>Income Tax</option>
                <option>Other</option>
              </select>
            </label>

            <label className="block">
              <span className="mb-1 block text-[11px] font-medium text-slate-600">
                Period start
              </span>
              <input
                name="periodStart"
                type="date"
                required
                className="h-9 w-full border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-slate-700 focus:ring-1 focus:ring-slate-700"
              />
            </label>

            <label className="block">
              <span className="mb-1 block text-[11px] font-medium text-slate-600">
                Period end
              </span>
              <input
                name="periodEnd"
                type="date"
                required
                className="h-9 w-full border border-slate-300 bg-white px-3 text-sm text-slate-900 outline-none focus:border-slate-700 focus:ring-1 focus:ring-slate-700"
              />
            </label>

            <button
              type="submit"
              className="h-9 self-end bg-slate-950 px-4 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              Prepare return
            </button>
          </form>
        </section>

        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5">
            <span className="text-xs font-medium text-slate-600">
              Tax returns
            </span>
            <span className="text-xs text-slate-500">
              {rows.length} {rows.length === 1 ? "return" : "returns"}
            </span>
          </div>

          {rows.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <p className="text-sm font-medium text-slate-900">
                No tax returns prepared
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Prepare a return above to see it here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm table">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Return
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Period
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Output VAT
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Input VAT
                    </th>
                    <th className="px-3 py-2 text-right text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Net VAT
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Status
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {rows.map((taxReturn) => (
                    <tr
                      key={taxReturn.id}
                      className="transition hover:bg-slate-50"
                    >
                      <td className="whitespace-nowrap px-3 py-2.5 font-medium text-slate-900">
                        {taxReturn.returnType}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                        {taxReturn.periodStart.toLocaleDateString("en-ZA")} –{" "}
                        {taxReturn.periodEnd.toLocaleDateString("en-ZA")}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right tabular-nums text-slate-900">
                        R{Number(taxReturn.outputVat).toFixed(2)}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right tabular-nums text-slate-900">
                        R{Number(taxReturn.inputVat).toFixed(2)}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-right font-medium tabular-nums text-slate-900">
                        R{Number(taxReturn.netVat).toFixed(2)}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5">
                        <span className="badge">{taxReturn.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}