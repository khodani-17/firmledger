import Link from "next/link";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";
import { addBankTransaction, reconcileBankTransaction } from "@/app/actions";

export default async function Reconciliation() {
  const u=await requireRole(["OWNER","ADMIN","FINANCE","ACCOUNTANT"]);
  const [rows,banks,payments]=await Promise.all([
    prisma.bankTransaction.findMany({where:{bankAccount:{firmId:u.firmId},matched:false},include:{bankAccount:true},orderBy:{transactionDate:"desc"}}),
    prisma.bankAccount.findMany({where:{firmId:u.firmId,active:true},orderBy:{name:"asc"}}),
    prisma.payment.findMany({where:{firmId:u.firmId,status:"COMPLETED",bankTransactions:{none:{}}},include:{client:true,invoice:true},orderBy:{paymentDate:"desc"}})
  ]);
  return <div className="shell"><aside className="sidebar"><div className="brand">Firm<span>Ledger</span></div><Link className="nav-link" href="/banking">← Banking</Link><Link className="nav-link active" href="/banking/reconciliation">Reconciliation</Link></aside><main className="main"><section className="content"><div className="page-heading"><div><h1 className="page-title">Bank reconciliation</h1><p className="page-subtitle">Match imported bank receipts to recorded client payments.</p></div></div>
    <div className="grid grid-2" style={{marginTop:24}}><div className="card"><div className="section-title">Add bank transaction</div><form action={addBankTransaction} className="form-card" style={{maxWidth:"none"}}><label>Bank<select name="bankAccountId" required><option value="">Select</option>{banks.map(b=><option key={b.id} value={b.id}>{b.name}</option>)}</select></label><label>Description<input name="description" required placeholder="Incoming EFT" /></label><label>Reference<input name="reference" placeholder="Bank reference" /></label><label>Amount<input name="amount" type="number" min="0.01" step="0.01" required /></label><label>Type<select name="type" defaultValue="CREDIT"><option value="CREDIT">Credit / money in</option><option value="DEBIT">Debit / money out</option></select></label><button className="primary-button" type="submit">Add transaction</button></form></div>
    <div className="card"><div className="section-title">Unmatched transactions</div>{rows.length ? rows.map(t=><div key={t.id} style={{borderBottom:"1px solid var(--border)",padding:"14px 0"}}><strong>{t.description}</strong><div className="metric-label">{t.bankAccount.name} · {t.reference||"No reference"} · R{Number(t.amount).toFixed(2)}</div>{t.type === "CREDIT" ? <form action={reconcileBankTransaction} style={{marginTop:10,display:"flex",gap:8}}><input type="hidden" name="bankTransactionId" value={t.id}/><select name="paymentId" required style={{flex:1}}><option value="">Select matching payment</option>{payments.filter(p=>Math.abs(Number(p.amount)-Number(t.amount))<0.001).map(p=><option key={p.id} value={p.id}>{p.invoice?.invoiceNumber||"Payment"} — {p.client?.displayName||"Client"} — R{Number(p.amount).toFixed(2)}</option>)}</select><button className="primary-button" type="submit">Match</button></form> : <span className="badge">Debit — manual review</span>}</div>) : <p className="page-subtitle">No unmatched transactions.</p>}</div></div>
  </section></main></div>;
}
