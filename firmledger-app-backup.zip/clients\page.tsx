import Link from "next/link";
import { requireUser } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function ClientsPage() {
  const user = await requireUser();
  const clients = await prisma.client.findMany({ where: { firmId: user.firmId }, include: { _count: { select: { matters: true } } }, orderBy: { displayName: "asc" } });
  return <Page title="Clients" subtitle="The people and organisations your firm acts for." action={<Link className="primary-button" href="/clients/new">New client</Link>}>
    <div className="card"><table className="table"><thead><tr><th>Client</th><th>Code</th><th>Type</th><th>Matters</th><th>Contact</th></tr></thead><tbody>{clients.map(c=><tr key={c.id}><td><strong>{c.displayName}</strong></td><td>{c.clientCode}</td><td>{c.type}</td><td>{c._count.matters}</td><td>{c.email ?? c.phone ?? "—"}</td></tr>)}</tbody></table></div>
  </Page>;
}
function Page({title,subtitle,action,children}:{title:string;subtitle:string;action:React.ReactNode;children:React.ReactNode}){return <div className="shell"><aside className="sidebar"><div className="brand">Firm<span>Ledger</span></div><Link className="nav-link" href="/">← Dashboard</Link><Link className="nav-link active" href="/clients">Clients</Link><Link className="nav-link" href="/matters">Matters</Link><Link className="nav-link" href="/billing">Billing</Link></aside><main className="main"><header className="topbar"><strong>Client management</strong></header><section className="content"><div className="page-heading"><div><h1 className="page-title">{title}</h1><p className="page-subtitle">{subtitle}</p></div>{action}</div><div style={{marginTop:24}}>{children}</div></section></main></div>}
