import Link from "next/link";
import { requireUser } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function Payments() {
  const u = await requireUser();

  const rows = await prisma.payment.findMany({
    where: {
      firmId: u.firmId,
    },
    include: {
      client: true,
      invoice: true,
    },
    orderBy: {
      paymentDate: "desc",
    },
  });

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="flex items-center justify-between gap-4">
            <h1 className="text-sm font-semibold tracking-tight text-slate-950">
              Payments
            </h1>

            <Link
              href="/payments/new"
              className="inline-flex h-9 items-center justify-center bg-slate-950 px-4 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              Record payment
            </Link>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] px-6 py-2">
        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2">
            <span className="text-xs text-slate-500">
              {rows.length} {rows.length === 1 ? "payment" : "payments"}
            </span>
          </div>

          {rows.length === 0 ? (
            <div className="px-4 py-6 text-center">
              <p className="text-sm font-medium text-slate-900">
                No payments recorded
              </p>

              <p className="mt-1 text-xs text-slate-500">
                Record a payment to see it here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Client</th>
                    <th>Invoice</th>
                    <th>Status</th>
                    <th>Amount</th>
                  </tr>
                </thead>

                <tbody>
                  {rows.map((payment) => (
                    <tr key={payment.id}>
                      <td>
                        {payment.paymentDate.toLocaleDateString("en-ZA")}
                      </td>

                      <td>
                        {payment.client?.displayName ?? "—"}
                      </td>

                      <td>
                        {payment.invoice?.invoiceNumber ?? "Unallocated"}
                      </td>

                      <td>
                        <span className="badge">
                          {payment.status}
                        </span>
                      </td>

                      <td className="amount">
                        R{Number(payment.amount).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
