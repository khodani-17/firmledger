import Link from "next/link";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function Suppliers() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const rows = await prisma.supplier.findMany({
    where: { firmId: u.firmId },
    orderBy: { name: "asc" },
  });

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-[1600px] px-6 py-2">
          <div className="flex items-center justify-between gap-4">
            <h1 className="text-sm font-semibold tracking-tight text-slate-950">
              Suppliers
            </h1>

            <Link
              href="/suppliers/new"
              className="inline-flex h-9 items-center justify-center bg-slate-950 px-4 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              New supplier
            </Link>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1600px] px-6 py-2">
        <section className="border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2.5">
            <span className="text-xs text-slate-500">
              {rows.length} {rows.length === 1 ? "supplier" : "suppliers"}
            </span>
          </div>

          {rows.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <p className="text-sm font-medium text-slate-900">
                No suppliers found
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Create a supplier to see it here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm table">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50">
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Code
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Supplier
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      VAT number
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Email
                    </th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                      Status
                    </th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-100">
                  {rows.map((supplier) => (
                    <tr
                      key={supplier.id}
                      className="transition hover:bg-slate-50"
                    >
                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                        {supplier.supplierCode}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 font-medium text-slate-900">
                        {supplier.name}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5 text-slate-600">
                        {supplier.vatNumber || "—"}
                      </td>

                      <td className="px-3 py-2.5 text-slate-600">
                        {supplier.email || "—"}
                      </td>

                      <td className="whitespace-nowrap px-3 py-2.5">
                        <span className="badge">
                          {supplier.active ? "Active" : "Inactive"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </main>
  );
}