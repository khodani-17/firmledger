import Link from "next/link";
import { createPurchaseInvoice } from "@/app/actions";
import { requireRole } from "@/lib/permissions";
import { prisma } from "@/lib/prisma";

export default async function NewPurchase() {
  const u = await requireRole([
    "OWNER",
    "ADMIN",
    "FINANCE",
    "ACCOUNTANT",
  ]);

  const [suppliers, matters] = await Promise.all([
    prisma.supplier.findMany({
      where: {
        firmId: u.firmId,
        active: true,
      },
      orderBy: {
        name: "asc",
      },
    }),
    prisma.matter.findMany({
      where: {
        firmId: u.firmId,
        status: {
          not: "ARCHIVED",
        },
      },
      include: {
        client: true,
      },
      orderBy: {
        matterNumber: "desc",
      },
    }),
  ]);

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          Firm<span>Ledger</span>
        </div>

        <Link className="nav-link" href="/purchases">
          ← Purchase invoices
        </Link>
      </aside>

      <main className="main">
        <section className="content">
          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "space-between",
              gap: "24px",
              marginBottom: "28px",
            }}
          >
            <div>
              <div
                className="metric-label"
                style={{
                  marginBottom: "8px",
                }}
              >
                ACCOUNTS PAYABLE
              </div>

              <h1
                className="page-title"
                style={{
                  marginBottom: "8px",
                }}
              >
                New purchase invoice
              </h1>

              <p
                style={{
                  margin: 0,
                  color: "#667085",
                  fontSize: "14px",
                  lineHeight: 1.6,
                }}
              >
                Record a supplier invoice and create the accounts payable
                entry.
              </p>
            </div>

            <Link className="secondary-button" href="/purchases">
              Cancel
            </Link>
          </div>

          <form action={createPurchaseInvoice}>
            <div
              className="card"
              style={{
                padding: "28px",
                maxWidth: "950px",
              }}
            >
              {/* Supplier and invoice information */}
              <div style={{ marginBottom: "24px" }}>
                <h2
                  style={{
                    margin: 0,
                    fontSize: "17px",
                    fontWeight: 650,
                  }}
                >
                  Invoice details
                </h2>

                <p
                  style={{
                    margin: "6px 0 0",
                    color: "#667085",
                    fontSize: "13px",
                  }}
                >
                  Enter the supplier and invoice information.
                </p>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "minmax(0, 1.4fr) minmax(0, 1fr)",
                  gap: "22px",
                }}
              >
                <div>
                  <label
                    htmlFor="supplierId"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Supplier
                  </label>

                  <select
                    id="supplierId"
                    name="supplierId"
                    required
                    defaultValue=""
                    style={{
                      width: "100%",
                      minHeight: "46px",
                      padding: "0 14px",
                      border: "1px solid #d0d5dd",
                      borderRadius: "8px",
                      background: "#fff",
                      fontSize: "14px",
                      outline: "none",
                    }}
                  >
                    <option value="" disabled>
                      Select supplier
                    </option>

                    {suppliers.map((supplier) => (
                      <option key={supplier.id} value={supplier.id}>
                        {supplier.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="invoiceNumber"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Supplier invoice number
                  </label>

                  <input
                    id="invoiceNumber"
                    name="invoiceNumber"
                    required
                    placeholder="e.g. INV-2026-001"
                    style={{
                      width: "100%",
                      minHeight: "46px",
                      padding: "0 14px",
                      border: "1px solid #d0d5dd",
                      borderRadius: "8px",
                      background: "#fff",
                      fontSize: "14px",
                      outline: "none",
                    }}
                  />
                </div>
              </div>

              <div style={{ marginTop: "22px" }}>
                <label
                  htmlFor="description"
                  style={{
                    display: "block",
                    fontSize: "13px",
                    fontWeight: 600,
                    marginBottom: "8px",
                  }}
                >
                  Description
                </label>

                <input
                  id="description"
                  name="description"
                  required
                  placeholder="e.g. Legal stationery supply"
                  style={{
                    width: "100%",
                    minHeight: "46px",
                    padding: "0 14px",
                    border: "1px solid #d0d5dd",
                    borderRadius: "8px",
                    background: "#fff",
                    fontSize: "14px",
                    outline: "none",
                  }}
                />
              </div>

              {/* Allocation */}
              <div
                style={{
                  height: "1px",
                  background: "#eaecf0",
                  margin: "30px 0",
                }}
              />

              <div style={{ marginBottom: "22px" }}>
                <h2
                  style={{
                    margin: 0,
                    fontSize: "17px",
                    fontWeight: 650,
                  }}
                >
                  Allocation
                </h2>

                <p
                  style={{
                    margin: "6px 0 0",
                    color: "#667085",
                    fontSize: "13px",
                  }}
                >
                  Link the supplier invoice to a matter, or record it as a
                  firm expense.
                </p>
              </div>

              <div>
                <label
                  htmlFor="matterId"
                  style={{
                    display: "block",
                    fontSize: "13px",
                    fontWeight: 600,
                    marginBottom: "8px",
                  }}
                >
                  Matter
                </label>

                <select
                  id="matterId"
                  name="matterId"
                  defaultValue=""
                  style={{
                    width: "100%",
                    minHeight: "46px",
                    padding: "0 14px",
                    border: "1px solid #d0d5dd",
                    borderRadius: "8px",
                    background: "#fff",
                    fontSize: "14px",
                    outline: "none",
                  }}
                >
                  <option value="">Firm expense</option>

                  {matters.map((matter) => (
                    <option key={matter.id} value={matter.id}>
                      {matter.matterNumber} · {matter.client.displayName}
                    </option>
                  ))}
                </select>
              </div>

              {/* Financial details */}
              <div
                style={{
                  height: "1px",
                  background: "#eaecf0",
                  margin: "30px 0",
                }}
              />

              <div style={{ marginBottom: "22px" }}>
                <h2
                  style={{
                    margin: 0,
                    fontSize: "17px",
                    fontWeight: 650,
                  }}
                >
                  Financial details
                </h2>

                <p
                  style={{
                    margin: "6px 0 0",
                    color: "#667085",
                    fontSize: "13px",
                  }}
                >
                  Enter the supplier invoice amounts.
                </p>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "minmax(0, 1fr) minmax(0, 1fr)",
                  gap: "22px",
                }}
              >
                <div>
                  <label
                    htmlFor="subtotal"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Subtotal
                  </label>

                  <div
                    style={{
                      position: "relative",
                    }}
                  >
                    <span
                      style={{
                        position: "absolute",
                        left: "14px",
                        top: "50%",
                        transform: "translateY(-50%)",
                        color: "#667085",
                        fontSize: "14px",
                        pointerEvents: "none",
                      }}
                    >
                      R
                    </span>

                    <input
                      id="subtotal"
                      name="subtotal"
                      type="number"
                      min="0.01"
                      step="0.01"
                      required
                      placeholder="0.00"
                      style={{
                        width: "100%",
                        minHeight: "46px",
                        padding: "0 14px 0 32px",
                        border: "1px solid #d0d5dd",
                        borderRadius: "8px",
                        background: "#fff",
                        fontSize: "14px",
                        outline: "none",
                      }}
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="taxAmount"
                    style={{
                      display: "block",
                      fontSize: "13px",
                      fontWeight: 600,
                      marginBottom: "8px",
                    }}
                  >
                    Input VAT
                  </label>

                  <div
                    style={{
                      position: "relative",
                    }}
                  >
                    <span
                      style={{
                        position: "absolute",
                        left: "14px",
                        top: "50%",
                        transform: "translateY(-50%)",
                        color: "#667085",
                        fontSize: "14px",
                        pointerEvents: "none",
                      }}
                    >
                      R
                    </span>

                    <input
                      id="taxAmount"
                      name="taxAmount"
                      type="number"
                      min="0"
                      step="0.01"
                      defaultValue="0"
                      placeholder="0.00"
                      style={{
                        width: "100%",
                        minHeight: "46px",
                        padding: "0 14px 0 32px",
                        border: "1px solid #d0d5dd",
                        borderRadius: "8px",
                        background: "#fff",
                        fontSize: "14px",
                        outline: "none",
                      }}
                    />
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div
                style={{
                  marginTop: "28px",
                  padding: "18px 20px",
                  borderRadius: "8px",
                  background: "#f8f9fb",
                  border: "1px solid #eaecf0",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: "20px",
                  }}
                >
                  <div>
                    <div
                      style={{
                        fontSize: "13px",
                        color: "#667085",
                        marginBottom: "4px",
                      }}
                    >
                      Invoice total
                    </div>

                    <div
                      style={{
                        fontSize: "13px",
                        color: "#98a2b3",
                      }}
                    >
                      Subtotal + input VAT
                    </div>
                  </div>

                  <div
                    style={{
                      fontSize: "22px",
                      fontWeight: 700,
                      letterSpacing: "-0.02em",
                    }}
                  >
                    Calculated on posting
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  gap: "12px",
                  marginTop: "30px",
                  paddingTop: "22px",
                  borderTop: "1px solid #eaecf0",
                }}
              >
                <Link className="secondary-button" href="/purchases">
                  Cancel
                </Link>

                <button className="primary-button" type="submit">
                  Post purchase invoice
                </button>
              </div>
            </div>
          </form>
        </section>
      </main>
    </div>
  );
}